# import torch
#
# def calculate_predicted_flow(render_t_1, render_t_2):
#     """
#     Calculates the predicted Gaussian Flow based on the change in 3D Gaussian parameters
#     between two time steps (t_1 and t_2), using outputs from the differentiable rasterizer.
#
#     Args:
#         render_t_1 (dict): Output dictionary from the rasterizer at time t_1.
#                           Expected keys: 'proj_2D', 'gs_per_pixel', 'weight_per_gs_pixel',
#                                          'x_mu', 'conic_2D'.
#         render_t_2 (dict): Output dictionary from the rasterizer at time t_2.
#                           Expected keys: 'proj_2D', 'conic_2D', 'conic_2D_inv'.
#
#     Returns:
#         torch.Tensor: The predicted flow tensor of shape (K, H, W, 2), where K is the number
#                       of top-K Gaussians considered per pixel, H and W are the image height
#                       and width, and 2 represents the x and y flow components.
#                       Each entry [k, h, w, :] is the flow contribution of the k-th Gaussian
#                       to the pixel at (h, w).
#     """
#     # --- Get parameters from t_1 (detach where needed for gradient flow control) ---
#     proj_2D_t_1 = render_t_1["proj_2D"] # Shape: (N, 2)
#     gs_per_pixel = render_t_1["gs_per_pixel"].long() # Shape: (K, H, W)
#     weight_per_gs_pixel = render_t_1["weight_per_gs_pixel"] # Shape: (K, H, W)
#     x_mu_t_1 = render_t_1["x_mu"] # Shape: (K, H, W, 2)
#     cov2D_inv_t_1 = render_t_1["conic_2D"].detach() # Shape: (N, 3), detached
#
#     # --- Get parameters from t_2 ---
#     proj_2D_t_2 = render_t_2["proj_2D"] # Shape: (N, 2)
#     cov2D_inv_t_2 = render_t_2["conic_2D"] # Shape: (N, 3) (inverse cov2D)
#     cov2D_t_2 = render_t_2["conic_2D_inv"] # Shape: (N, 3) (cov2D)
#
#     # --- Reshape 3D conic representations to 2x2 matrices ---
#     # t_2 Covariance Matrix (Cov2D)
#     cov2D_t_2_mtx = torch.zeros([cov2D_t_2.shape[0], 2, 2], device=cov2D_t_2.device, dtype=cov2D_t_2.dtype)
#     cov2D_t_2_mtx[:, 0, 0] = cov2D_t_2[:, 0]
#     cov2D_t_2_mtx[:, 0, 1] = cov2D_t_2[:, 1]
#     cov2D_t_2_mtx[:, 1, 0] = cov2D_t_2[:, 1]
#     cov2D_t_2_mtx[:, 1, 1] = cov2D_t_2[:, 2]
#
#     # t_1 Inverse Covariance Matrix (Cov2D_inv), detached
#     cov2D_inv_t_1_mtx = torch.zeros([cov2D_inv_t_1.shape[0], 2, 2], device=cov2D_inv_t_1.device, dtype=cov2D_inv_t_1.dtype)
#     cov2D_inv_t_1_mtx[:, 0, 0] = cov2D_inv_t_1[:, 0]
#     cov2D_inv_t_1_mtx[:, 0, 1] = cov2D_inv_t_1[:, 1]
#     cov2D_inv_t_1_mtx[:, 1, 0] = cov2D_inv_t_1[:, 1]
#     cov2D_inv_t_1_mtx[:, 1, 1] = cov2D_inv_t_1[:, 2]
#
#     # --- Compute matrix square roots (B = sqrt(Cov)) using SVD ---
#     # B_t_2 (sqrt of Cov2D_t_2)
#     U_t_2, S_t_2, V_t_2 = torch.svd(cov2D_t_2_mtx)
#     B_t_2 = torch.bmm(torch.bmm(U_t_2, torch.diag_embed(torch.sqrt(S_t_2))), V_t_2.transpose(-2, -1))
#
#     # B_t_1_inv (sqrt of Cov2D_inv_t_1, detached)
#     U_inv_t_1, S_inv_t_1, V_inv_t_1 = torch.svd(cov2D_inv_t_1_mtx)
#     B_inv_t_1 = torch.bmm(torch.bmm(U_inv_t_1, torch.diag_embed(torch.sqrt(S_inv_t_1))), V_inv_t_1.transpose(-2, -1))
#
#     # --- Calculate B_t_2 * B_t_1^(-1) ---
#     B_t_2_B_inv_t_1 = torch.bmm(B_t_2, B_inv_t_1) # Shape: (N, 2, 2)
#
#     # --- Calculate the flow contribution ---
#     # Permute x_mu from (K, H, W, 2) to (H, W, K, 2), then unsqueeze to (H, W, K, 2, 1), detach
#     x_mu_t_1_p = x_mu_t_1.permute(1, 2, 0, 3).unsqueeze(-1).detach() # Shape: (H, W, K, 2, 1)
#
#     # Select transformation matrices for top-K Gaussians per pixel: (H, W, K, 2, 2)
#     B_t_2_B_inv_t_1_selected = B_t_2_B_inv_t_1[gs_per_pixel.permute(1, 2, 0)] # gs_per_pixel: (K, H, W) -> (H, W, K)
#
#     # Calculate cov_multi: (H, W, K, 2, 1) = (H, W, K, 2, 2) @ (H, W, K, 2, 1)
#     cov_multi_intermediate = torch.matmul(B_t_2_B_inv_t_1_selected, x_mu_t_1_p)
#     cov_multi = cov_multi_intermediate.squeeze(-1) # Shape: (H, W, K, 2)
#
#     # Calculate position difference: (H, W, K, 2) = (N, 2)[(K, H, W)] - (N, 2)[(K, H, W)].detach()
#     # Need to permute gs_per_pixel back for indexing: (K, H, W) -> (H, W, K)
#     pos_diff_intermediate = (proj_2D_t_2[gs_per_pixel.permute(1, 2, 0)] - proj_2D_t_1[gs_per_pixel.permute(1, 2, 0)].detach()) # Shape: (H, W, K, 2)
#     # Permute back to (K, H, W, 2) to match final output
#     pos_diff = pos_diff_intermediate.permute(2, 0, 1, 3)
#
#     # Calculate x_mu_t_1 contribution: (H, W, K, 2), then permute back
#     x_mu_contrib_intermediate = x_mu_t_1.permute(1, 2, 0, 3).detach() # Shape: (H, W, K, 2)
#     x_mu_contrib = x_mu_contrib_intermediate.permute(2, 0, 1, 3) # Shape: (K, H, W, 2)
#
#     # Calculate cov_multi contribution: (H, W, K, 2), then permute back
#     cov_multi_contrib_intermediate = cov_multi # Shape: (H, W, K, 2)
#     cov_multi_contrib = cov_multi_contrib_intermediate.permute(2, 0, 1, 3) # Shape: (K, H, W, 2)
#
#
#     # --- Full formulation of GaussianFlow ---
#     # Sum contributions: (K, H, W, 2) = (K, H, W, 2) + (K, H, W, 2) - (K, H, W, 2) - (K, H, W, 2)
#     # Note: pos_diff is already in (K, H, W, 2) after permute
#     flow_contributions = (cov_multi_contrib + pos_diff - x_mu_contrib) # Shape: (K, H, W, 2)
#
#     # Apply weights: (K, H, W, 2) = (K, H, W, 2) * (K, H, W, 1)
#     predicted_flow_by_gs = flow_contributions * weight_per_gs_pixel.unsqueeze(-1).detach() # Shape: (K, H, W, 2)
#
#     return predicted_flow_by_gs
#
# # Example usage (assuming render_t_1 and render_t_2 are obtained from the rasterizer):
# # predicted_flow = calculate_predicted_flow(render_t_1, render_t_2)
# # predicted_flow_sum = predicted_flow.sum(0) # Shape: (H, W, 2) - The final 2D flow map


import torch

def calculate_predicted_flow(render_t_1, render_t_2):
    """
    Calculates the predicted Gaussian Flow based on the change in 3D Gaussian parameters
    between two time steps (t_1 and t_2), using outputs from the differentiable rasterizer.

    Args:
        render_t_1 (dict): Output dictionary from the rasterizer at time t_1.
                          Expected keys: 'proj_2D', 'gs_per_pixel', 'weight_per_gs_pixel',
                                         'x_mu', 'conic_2D'.
        render_t_2 (dict): Output dictionary from the rasterizer at time t_2.
                          Expected keys: 'proj_2D', 'conic_2D', 'conic_2D_inv'.

    Returns:
        torch.Tensor: The predicted flow tensor of shape (K, H, W, 2), where K is the number
                      of top-K Gaussians considered per pixel, H and W are the image height
                      and width, and 2 represents the x and y flow components.
                      Each entry [k, h, w, :] is the flow contribution of the k-th Gaussian
                      to the pixel at (h, w).
    """
    # --- Get parameters from t_1 (detach where needed for gradient flow control) ---
    proj_2D_t_1 = render_t_1["proj_2D"] # Shape: (N, 2) -> actual: (230400, 2)
    gs_per_pixel = render_t_1["gs_per_pixel"].long() # Shape: (K, H, W) -> actual: (20, 240, 320)
    weight_per_gs_pixel = render_t_1["weight_per_gs_pixel"] # Shape: (K, H, W) -> actual: (20, 240, 320)
    x_mu_t_1 = render_t_1["x_mu"] # Shape: (K, 2, H, W) -> actual: (20, 2, 240, 320)
    cov2D_inv_t_1 = render_t_1["conic_2D"].detach() # Shape: (N, 3), detached -> actual: (230400, 3)

    # --- Get parameters from t_2 ---
    proj_2D_t_2 = render_t_2["proj_2D"] # Shape: (N, 2) -> actual: (230400, 2)
    cov2D_inv_t_2 = render_t_2["conic_2D"] # Shape: (N, 3) (inverse cov2D) -> actual: (230400, 3)
    cov2D_t_2 = render_t_2["conic_2D_inv"] # Shape: (N, 3) (cov2D) -> actual: (230400, 3)

    # Get dimensions
    K, _, H, W = x_mu_t_1.shape  # K=20, H=240, W=320
    N = proj_2D_t_1.shape[0]  # N=230400

    # --- Reshape 3D conic representations to 2x2 matrices ---
    # t_2 Covariance Matrix (Cov2D)
    cov2D_t_2_mtx = torch.zeros([cov2D_t_2.shape[0], 2, 2], device=cov2D_t_2.device, dtype=cov2D_t_2.dtype)
    cov2D_t_2_mtx[:, 0, 0] = cov2D_t_2[:, 0]
    cov2D_t_2_mtx[:, 0, 1] = cov2D_t_2[:, 1]
    cov2D_t_2_mtx[:, 1, 0] = cov2D_t_2[:, 1]
    cov2D_t_2_mtx[:, 1, 1] = cov2D_t_2[:, 2]

    # t_1 Inverse Covariance Matrix (Cov2D_inv), detached
    cov2D_inv_t_1_mtx = torch.zeros([cov2D_inv_t_1.shape[0], 2, 2], device=cov2D_inv_t_1.device, dtype=cov2D_inv_t_1.dtype)
    cov2D_inv_t_1_mtx[:, 0, 0] = cov2D_inv_t_1[:, 0]
    cov2D_inv_t_1_mtx[:, 0, 1] = cov2D_inv_t_1[:, 1]
    cov2D_inv_t_1_mtx[:, 1, 0] = cov2D_inv_t_1[:, 1]
    cov2D_inv_t_1_mtx[:, 1, 1] = cov2D_inv_t_1[:, 2]

    # --- Compute matrix square roots (B = sqrt(Cov)) using SVD ---
    # B_t_2 (sqrt of Cov2D_t_2)
    U_t_2, S_t_2, V_t_2 = torch.svd(cov2D_t_2_mtx)
    B_t_2 = torch.bmm(torch.bmm(U_t_2, torch.diag_embed(torch.sqrt(S_t_2))), V_t_2.transpose(-2, -1))

    # B_t_1_inv (sqrt of Cov2D_inv_t_1, detached)
    U_inv_t_1, S_inv_t_1, V_inv_t_1 = torch.svd(cov2D_inv_t_1_mtx)
    B_inv_t_1 = torch.bmm(torch.bmm(U_inv_t_1, torch.diag_embed(torch.sqrt(S_inv_t_1))), V_inv_t_1.transpose(-2, -1))

    # --- Calculate B_t_2 * B_t_1^(-1) ---
    B_t_2_B_inv_t_1 = torch.bmm(B_t_2, B_inv_t_1) # Shape: (N, 2, 2) -> (230400, 2, 2)

    # --- Calculate the flow contribution ---
    # x_mu_t_1 is (K, 2, H, W), need to permute to (H, W, K, 2), then unsqueeze to (H, W, K, 2, 1), detach
    x_mu_t_1_p = x_mu_t_1.permute(2, 3, 0, 1).unsqueeze(-1).detach() # Shape: (H, W, K, 2, 1) -> (240, 320, 20, 2, 1)

    # Select transformation matrices for top-K Gaussians per pixel: (H, W, K, 2, 2)
    # gs_per_pixel is (K, H, W), need to permute to (H, W, K) for indexing
    gs_per_pixel_perm = gs_per_pixel.permute(1, 2, 0)  # (H, W, K) -> (240, 320, 20)
    B_t_2_B_inv_t_1_selected = B_t_2_B_inv_t_1[gs_per_pixel_perm] # Shape: (H, W, K, 2, 2) -> (240, 320, 20, 2, 2)

    # Calculate cov_multi: (H, W, K, 2, 1) = (H, W, K, 2, 2) @ (H, W, K, 2, 1)
    cov_multi_intermediate = torch.matmul(B_t_2_B_inv_t_1_selected, x_mu_t_1_p)  # (240, 320, 20, 2, 1)
    cov_multi = cov_multi_intermediate.squeeze(-1) # Shape: (H, W, K, 2) -> (240, 320, 20, 2)

    # Calculate position difference: (H, W, K, 2) = (N, 2)[(K, H, W)] - (N, 2)[(K, H, W)].detach()
    # Need to use gs_per_pixel_perm for indexing: (H, W, K)
    pos_diff_intermediate = (proj_2D_t_2[gs_per_pixel_perm] - proj_2D_t_1[gs_per_pixel_perm].detach()) # Shape: (H, W, K, 2) -> (240, 320, 20, 2)
    # Permute back to (K, H, W, 2) to match final output
    pos_diff = pos_diff_intermediate.permute(2, 0, 1, 3)  # (K, H, W, 2) -> (20, 240, 320, 2)

    # Calculate x_mu_t_1 contribution: (H, W, K, 2), then permute back
    x_mu_contrib_intermediate = x_mu_t_1.permute(2, 3, 0, 1).detach() # Shape: (H, W, K, 2) -> (240, 320, 20, 2)
    x_mu_contrib = x_mu_contrib_intermediate.permute(2, 0, 1, 3) # Shape: (K, H, W, 2) -> (20, 240, 320, 2)

    # Calculate cov_multi contribution: (H, W, K, 2), then permute back
    cov_multi_contrib_intermediate = cov_multi # Shape: (H, W, K, 2) -> (240, 320, 20, 2)
    cov_multi_contrib = cov_multi_contrib_intermediate.permute(2, 0, 1, 3) # Shape: (K, H, W, 2) -> (20, 240, 320, 2)

    # --- Full formulation of GaussianFlow ---
    # Sum contributions: (K, H, W, 2) = (K, H, W, 2) + (K, H, W, 2) - (K, H, W, 2) - (K, H, W, 2)
    # Note: pos_diff is already in (K, H, W, 2) after permute
    flow_contributions = (cov_multi_contrib + pos_diff - x_mu_contrib) # Shape: (K, H, W, 2) -> (20, 240, 320, 2)

    # Apply weights: (K, H, W, 2) = (K, H, W, 2) * (K, H, W, 1)
    predicted_flow_by_gs = flow_contributions * weight_per_gs_pixel.unsqueeze(-1).detach() # Shape: (K, H, W, 2) -> (20, 240, 320, 2)
    predicted_flow_sum = predicted_flow_by_gs.sum(0)



    return predicted_flow_sum

# Example usage (assuming render_t_1 and render_t_2 are obtained from the rasterizer):
# predicted_flow = calculate_predicted_flow(render_t_1, render_t_2)
# predicted_flow_sum = predicted_flow.sum(0) # Shape: (H, W, 2) - The final 2D flow map