from dataclasses import dataclass

from jaxtyping import Float
from torch import Tensor

from ..dataset.types import BatchedExample
from ..model.decoder.decoder import DecoderOutput
from ..model.types import Gaussians
from .loss import Loss
import torch

@dataclass
class LossMseCfg:
    weight: float


@dataclass
class LossMseCfgWrapper:
    mse: LossMseCfg


class LossMse(Loss[LossMseCfg, LossMseCfgWrapper]):
    def forward(
        self,
        prediction: DecoderOutput,
        batch: BatchedExample,
        gaussians: Gaussians,
        global_step: int,
    ) -> Float[Tensor, ""]:

        # delta = prediction.color - add_zero_channel(batch["target"]["flow"])
        # return self.cfg.weight * (delta[batch["context"]["action_mask"]]**2).mean()




        # batch["target"]["flow"].shape
        reshape_predflow = torch.reshape(batch["flow"],batch["target"]["flow"].shape)
        delta = reshape_predflow - batch["target"]["flow"]

        mask  = batch["context"]["action_mask"][:,:,0:2,:,:]
        delta = delta[mask]
        loss = self.cfg.weight * torch.abs(delta) .mean()


        return loss
def add_zero_channel(tensor):
    """
    将 (2, 1, 2, 240, 320) 的tensor添加一个全零通道变成 (2, 1, 3, 240, 320)
    新通道添加到最后一个通道位置
    """
    batch_size, dim1, channels, height, width = tensor.shape

    # 创建一个形状为 (2, 1, 1, 240, 320) 的全零tensor
    zero_channel = torch.zeros(batch_size, dim1, 1, height, width, dtype=tensor.dtype, device=tensor.device)

    # 将原tensor和零通道在通道维度上连接
    result = torch.cat([tensor, zero_channel], dim=2)

    return result


