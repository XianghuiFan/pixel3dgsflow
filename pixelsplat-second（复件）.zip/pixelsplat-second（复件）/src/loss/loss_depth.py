from dataclasses import dataclass

import torch
from einops import reduce
from jaxtyping import Float
from torch import Tensor

from ..dataset.types import BatchedExample
from ..model.decoder.decoder import DecoderOutput
from ..model.types import Gaussians
from .loss import Loss


@dataclass
class LossDepthCfg:
    weight: float
    sigma_image: float | None
    use_second_derivative: bool


# @dataclass
# class LossDepthCfg:
#     weight: float = 0.1  # 原有参数
#     depth_supervision_weight: float = 0.25  # 新增：深度真值监督权重
#     use_second_derivative: bool = False  # 原有参数
#     sigma_image: float = None  # 原有参数


@dataclass
class LossDepthCfgWrapper:
    depth: LossDepthCfg


# class LossDepth(Loss[LossDepthCfg, LossDepthCfgWrapper]):
#     def forward(
#         self,
#         prediction: DecoderOutput,
#         batch: BatchedExample,
#         gaussians: Gaussians,
#         global_step: int,
#     ) -> Float[Tensor, ""]:
#         # Scale the depth between the near and far planes.
#         near = batch["target"]["near"][..., None, None].log()
#         far = batch["target"]["far"][..., None, None].log()
#         depth = prediction.depth.minimum(far).maximum(near)
#         depth = (depth - near) / (far - near)
#
#         # Compute the difference between neighboring pixels in each direction.
#         depth_dx = depth.diff(dim=-1)
#         depth_dy = depth.diff(dim=-2)
#
#         # If desired, compute a 2nd derivative.
#         if self.cfg.use_second_derivative:
#             depth_dx = depth_dx.diff(dim=-1)
#             depth_dy = depth_dy.diff(dim=-2)
#
#         # If desired, add bilateral filtering.
#         if self.cfg.sigma_image is not None:
#             color_gt = batch["target"]["image"]
#             color_dx = reduce(color_gt.diff(dim=-1), "b v c h w -> b v h w", "max")
#             color_dy = reduce(color_gt.diff(dim=-2), "b v c h w -> b v h w", "max")
#             if self.cfg.use_second_derivative:
#                 color_dx = color_dx[..., :, 1:].maximum(color_dx[..., :, :-1])
#                 color_dy = color_dy[..., 1:, :].maximum(color_dy[..., :-1, :])
#             depth_dx = depth_dx * torch.exp(-color_dx * self.cfg.sigma_image)
#             depth_dy = depth_dy * torch.exp(-color_dy * self.cfg.sigma_image)
#
#         return self.cfg.weight * (depth_dx.abs().mean() + depth_dy.abs().mean())




# class LossDepth(Loss[LossDepthCfg, LossDepthCfgWrapper]):
#     def forward(
#             self,
#             prediction: DecoderOutput,
#             batch: BatchedExample,
#             gaussians: Gaussians,
#             global_step: int,
#     ) -> Float[Tensor, ""]:
#         # 获取高斯渲染的深度 (B, 1, 240, 320) -> (B, 240, 320)
#         rendered_depth = prediction.depth.squeeze(1)  # (B, 240, 320)
#
#         # 获取深度真值 (B, 1, 1, 240, 320) -> (B, 240, 320)
#         gt_depth = batch["target"]["depth"].squeeze(1).squeeze(1)  # (B, 240, 320)
#
#         # 创建有效深度mask (过滤掉不合理的深度值，如0或无穷大)
#         valid_mask = (gt_depth > 0) & (gt_depth < 1e4) & torch.isfinite(gt_depth)  # (B, 240, 320)
#
#         # 计算深度真值监督loss
#         depth_supervision_loss = 0.0
#         if valid_mask.any():
#             # 计算L1损失
#             depth_diff = (rendered_depth - gt_depth).abs()
#             depth_supervision_loss = (depth_diff * valid_mask).sum() / valid_mask.sum().clamp(min=1)
#
#         # Scale the depth between the near and far planes for smoothness term.
#         near = batch["target"]["near"][..., None, None].log()
#         far = batch["target"]["far"][..., None, None].log()
#         depth_normalized = prediction.depth.minimum(far).maximum(near)
#         depth_normalized = (depth_normalized - near) / (far - near)
#
#         # Compute the difference between neighboring pixels in each direction for smoothness.
#         depth_dx = depth_normalized.diff(dim=-1)
#         depth_dy = depth_normalized.diff(dim=-2)
#
#         # If desired, compute a 2nd derivative.
#         if self.cfg.use_second_derivative:
#             depth_dx = depth_dx.diff(dim=-1)
#             depth_dy = depth_dy.diff(dim=-2)
#
#         # If desired, add bilateral filtering.
#         if self.cfg.sigma_image is not None:
#             color_gt = batch["target"]["image"]
#             color_dx = reduce(color_gt.diff(dim=-1), "b v c h w -> b v h w", "max")
#             color_dy = reduce(color_gt.diff(dim=-2), "b v c h w -> b v h w", "max")
#             if self.cfg.use_second_derivative:
#                 color_dx = color_dx[..., :, 1:].maximum(color_dx[..., :, :-1])
#                 color_dy = color_dy[..., 1:, :].maximum(color_dy[..., :-1, :])
#             depth_dx = depth_dx * torch.exp(-color_dx * self.cfg.sigma_image)
#             depth_dy = depth_dy * torch.exp(-color_dy * self.cfg.sigma_image)
#
#         smoothness_loss = depth_dx.abs().mean() + depth_dy.abs().mean()
#
#         # 组合两种loss
#         total_loss = (
#                 self.cfg.weight * smoothness_loss +  # 原有的平滑性loss
#                 self.cfg.depth_supervision_weight * depth_supervision_loss  # 新增的真值监督loss
#         )
#
#         return total_loss


class LossDepth(Loss[LossDepthCfg, LossDepthCfgWrapper]):
    def forward(
            self,
            prediction: DecoderOutput,
            batch: BatchedExample,
            gaussians: Gaussians,
            global_step: int,
    ) -> Float[Tensor, ""]:
        # 检查是否有深度真值
        if "depth" in batch["target"]:
            # 获取渲染深度和真值深度
            rendered_depth = prediction.depth  # (B, 1, 240, 320)
            gt_depth = batch["target"]["depth"].squeeze(1).squeeze(1)  # (B, 240, 320)

            # 创建有效mask
            # valid_mask = (gt_depth > 0) & (gt_depth < 1e4) & torch.isfinite(gt_depth)& batch["context"]["action_mask"][:,0,0,:,:] # (B, 240, 320)
            valid_mask = (gt_depth > 0) & (gt_depth < 1e4) & torch.isfinite(gt_depth)
            # targt_action_mask = batch["context"]["action_mask"]
            # 计算深度真值监督loss
            if valid_mask.any():
                depth_diff = (rendered_depth.squeeze(1) - gt_depth).abs()  # (B, 240, 320)
                depth_supervision_loss = (depth_diff * valid_mask).sum() / valid_mask.sum().clamp(min=1)
            else:
                depth_supervision_loss = torch.tensor(0.0, device=rendered_depth.device)
        else:
            depth_supervision_loss = torch.tensor(0.0, device=prediction.depth.device)

        # Scale the depth between the near and far planes.
        near = batch["target"]["near"][..., None, None].log()
        far = batch["target"]["far"][..., None, None].log()
        depth = prediction.depth.minimum(far).maximum(near)
        depth = (depth - near) / (far - near)

        # Compute the difference between neighboring pixels in each direction.
        depth_dx = depth.diff(dim=-1)
        depth_dy = depth.diff(dim=-2)

        # If desired, compute a 2nd derivative.
        if self.cfg.use_second_derivative:
            depth_dx = depth_dx.diff(dim=-1)
            depth_dy = depth_dy.diff(dim=-2)

        # If desired, add bilateral filtering.
        if self.cfg.sigma_image is not None:
            color_gt = batch["target"]["image"]
            color_dx = reduce(color_gt.diff(dim=-1), "b v c h w -> b v h w", "max")
            color_dy = reduce(color_gt.diff(dim=-2), "b v c h w -> b v h w", "max")
            if self.cfg.use_second_derivative:
                color_dx = color_dx[..., :, 1:].maximum(color_dx[..., :, :-1])
                color_dy = color_dy[..., 1:, :].maximum(color_dy[..., :-1, :])
            depth_dx = depth_dx * torch.exp(-color_dx * self.cfg.sigma_image)
            depth_dy = depth_dy * torch.exp(-color_dy * self.cfg.sigma_image)

        smoothness_loss = depth_dx.abs().mean() + depth_dy.abs().mean()

        #组合两种loss，保持原有权重不变
        total_loss = (
            0.3*(0.2*self.cfg.weight * smoothness_loss +
                self.cfg.weight * depth_supervision_loss)  # 使用相同的权重，或者你可以调整比例
        )

        # total_loss = self.cfg.weight * smoothness_loss

        return total_loss