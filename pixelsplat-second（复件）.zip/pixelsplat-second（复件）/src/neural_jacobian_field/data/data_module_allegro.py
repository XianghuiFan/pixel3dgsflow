from pytorch_lightning import LightningDataModule
from torch.utils.data import DataLoader

# === 你需要确保这些类在新项目中可用 ===
# 建议将 dataset 类和 ValidationWrapper 复制到新项目，或通过 PYTHONPATH 引入
from .dataset import DatasetAllegro
from .dataset.dataset_hsa import DatasetHsa
from .dataset.dataset_toy_arm import DatasetToyArm
from .dataset.dataset_pneumatic import DatasetPneumaticHandOnly
from .validation_wrapper import ValidationWrapper

DATASETS = {
    "allegro": DatasetAllegro,
    "hsa": DatasetHsa,
    "toy_arm": DatasetToyArm,
    "pneumatic_hand_only": DatasetPneumaticHandOnly,
}


class ReusableDataModule(LightningDataModule):
    """
    可复用的 DataModule，不依赖特定配置结构。

    参数说明：
        dataset_name (str): 数据集名称，必须在 DATASETS 中
        dataset_cfg (Any): 传递给 dataset 的配置对象（通常是一个 OmegaConf DictConfig 或 dict）
        train_batch_size (int): 训练 batch size
        train_num_workers (int): 训练 dataloader 的 num_workers
        val_batch_size (int): 验证/测试 batch size
        val_num_workers (int): 验证/测试 dataloader 的 num_workers
    """

    def __init__(
            self,
            dataset_name: str,
            dataset_cfg,
            train_batch_size: int = 1,
            train_num_workers: int = 16,
            val_batch_size: int = 1,
            val_num_workers: int = 4,
    ):
        super().__init__()
        if dataset_name not in DATASETS:
            raise ValueError(f"Unknown dataset: {dataset_name}. Available: {list(DATASETS.keys())}")

        self.dataset_name = dataset_name
        self.dataset_cfg = dataset_cfg
        self.train_batch_size = train_batch_size
        self.train_num_workers = train_num_workers
        self.val_batch_size = val_batch_size
        self.val_num_workers = val_num_workers

    def train_dataloader(self):
        dataset_cls = DATASETS[self.dataset_name]
        dataset = dataset_cls(cfg=self.dataset_cfg, stage="train")
        return DataLoader(
            dataset,
            batch_size=self.train_batch_size,
            shuffle=True,
            num_workers=self.train_num_workers,
            persistent_workers=self.train_num_workers > 0,
            pin_memory=True,
        )

    def val_dataloader(self):
        dataset_cls = DATASETS[self.dataset_name]
        dataset = dataset_cls(cfg=self.dataset_cfg, stage="val")
        return DataLoader(
            ValidationWrapper(dataset, 1),
            batch_size=self.val_batch_size,
            num_workers=self.val_num_workers,
            persistent_workers=self.val_num_workers > 0,
            pin_memory=True,
        )

    def test_dataloader(self):
        dataset_cls = DATASETS[self.dataset_name]
        dataset = dataset_cls(cfg=self.dataset_cfg, stage="test")
        return DataLoader(
            ValidationWrapper(dataset, 1),
            batch_size=self.val_batch_size,
            num_workers=self.val_num_workers,
            persistent_workers=self.val_num_workers > 0,
            pin_memory=True,
        )