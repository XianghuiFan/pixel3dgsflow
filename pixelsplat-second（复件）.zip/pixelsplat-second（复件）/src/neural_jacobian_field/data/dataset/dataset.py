import random
from abc import ABC, abstractmethod
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path, PosixPath
from typing import Dict, Generic, List, Literal, Tuple, TypeVar

import cv2
import numpy as np
import torch
from jaxtyping import Float, Int
from nerfstudio.data.utils.data_utils import get_depth_image_from_path
from nerfstudio.utils import poses as pose_utils
from torch import Tensor
from torch.utils.data import Dataset

from ...rendering.geometry import get_pixel_coordinates
from ...utils import convention, io_utils, misc
from .config_parser import (
    Cameras,
    DNeRFDataParser,
    DNeRFDataParserConfig,
    DNeRFDataParserOutputs,
)
from .image_augmentation import RandomBackground, ZeroMaskPatchedImage
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path
import torchvision.utils as vutils
import os

Stage = Literal["train", "val", "test"]


@dataclass
class DatasetStandardItems:
    dataparser_scale: float
    image_filenames: List[Path]
    depth_filenames: List[str]
    depth_unit_scale_factor: float
    times: List[float]


@dataclass
class DatasetCameraItems:
    cameras: Cameras
    sample_to_camera_idx: Int[Tensor, "num_samples"]
    multiview_cam2worlds: Float[Tensor, "*camera 4 4"]
    multiview_intrinsics: Float[Tensor, "*camera 3 3"]
    coordinates: Float[Tensor, "height width 2"]


@dataclass
class DatasetActionItems:
    num_joints: int
    active_joints: List[int]
    keyname_to_qpos: Dict[str, Float[Tensor, "action_dim"]]
    qpos_minimum: Float[Tensor, "action_dim"]
    qpos_maximum: Float[Tensor, "action_dim"]


@dataclass
class DatasetItems:
    standard: DatasetStandardItems
    camera: DatasetCameraItems
    action: DatasetActionItems


@dataclass
class QposItems:
    curr_qpos: Float[Tensor, "action_dim"]
    next_qpos: Float[Tensor, "action_dim"]
    qpos_minimum: Float[Tensor, "action_dim"]
    qpos_maximum: Float[Tensor, "action_dim"]


@dataclass
class TrackSupervision:
    pixel_selector: Float[Tensor, "num_pixels"]
    pixel_motion: Float[Tensor, "num_pixels 2"]
    pixel_visible_mask: Float[Tensor, "num_pixels"]


@dataclass
class DatasetCfgCommon:
    name: str
    mode: Literal["perception", "action"]
    # file related
    overfit_to_scene: None | str
    root: Path
    other_roots: None | List[Path] | List[str]
    # action related
    num_total_joints: int
    disabled_joints: None | List[int]
    # creating supervision
    max_frame_displacement: int
    max_num_frames_per_traj: int
    action_supervision_type: Literal["optical_flow", "tracks"]
    num_positive_samples: int | None
    num_negative_samples: int | None
    # training
    augment_ctxt_image: bool
    # testing
    testing_mask_ratio: None | float = None
    # DatasetCommon.visualize_dataset_item = visualize_dataset_item
    # DatasetCommon.flow_to_color = flow_to_color
    # DatasetCommon.visualize_batch = visualize_batch

# T = TypeVar("T")


class DatasetCommon(Dataset):
    # cfg: DatasetCfgCommon
    near: float
    far: float
    repeat: int
    scale_factor: float
    dataset_items: DatasetItems

    def __init__(self, cfg, stage: Stage):
        self.cfg = cfg
        self.stage = stage

        # downscale_factor = 1 if (stage in ["train", "test"]) else 5
        downscale_factor = 2
        self.dataset_items = self.load_dataset(downscale_factor=downscale_factor)
        # data augmentation flags
        self.random_background = RandomBackground() if cfg.augment_ctxt_image else None
        if stage == "test":
            if cfg.testing_mask_ratio is not None:
                self.zero_background = ZeroMaskPatchedImage(
                    patch_size=20, mask_ratio=cfg.testing_mask_ratio
                )

    def load_dataset(self, downscale_factor: int = 1) -> DatasetItems:







        dataparser: DNeRFDataParser
        dataparser = DNeRFDataParserConfig(
            data=Path(self.cfg.root),
            center_method="focus",
            downscale_factor=downscale_factor,
        ).setup()

        dataparser_outputs: DNeRFDataParserOutputs
        dataparser_outputs = dataparser.get_dataparser_outputs(split="train")
        self._dataparser_outputs = dataparser_outputs

        if self.cfg.other_roots is not None:
            print(f"Combining roots! {self.cfg.other_roots}")
            total_dataparser_outputs = io_utils.combine_roots(
                self.cfg, dataparser_outputs, downscale_factor
            )
            # update dataparser_outputs
            dataparser_outputs = dataparser.merge_datparser_outputs(
                total_dataparser_outputs
            )
            self._dataparser_outputs = dataparser_outputs
            print(
                "Number of files of combining roots",
                len(dataparser_outputs.image_filenames),
            )

        metadata = deepcopy(dataparser_outputs.metadata)
        cameras = deepcopy(dataparser_outputs.cameras)

        # load camera-related
        sample_to_camera_idx = dataparser_outputs.sample_to_camera_idx
        multiview_cam2worlds = pose_utils.to4x4(cameras.camera_to_worlds)
        multiview_intrinsics = cameras.get_intrinsics_matrices()

        # load depth-related
        depth_filenames = metadata["depth_filenames"]


        depth_unit_scale_factor = metadata["depth_unit_scale_factor"]

        ### load image coordinates
        coordinates = cameras.get_image_coords()

        ### load action-related
        num_joints = self.cfg.num_total_joints
        active_joints = list(range(num_joints))
        if self.cfg.disabled_joints is not None:
            disabled_joints = self.cfg.disabled_joints
            # filter out disabled joints
            active_joints = [x for x in active_joints if x not in disabled_joints]

        times = metadata["times"]
        # unpack joint positions
        keyname_to_qpos: Dict[str, torch.tensor] = metadata["joint_positions"]
        qpos = torch.stack(list(keyname_to_qpos.values()), dim=0)
        qpos_minimum = qpos.min(0).values.float()
        qpos_maximum = qpos.max(0).values.float()

        # debug
        depth_filenames = [str(p) for p in metadata["depth_filenames"]]
        times = [float(t) for t in metadata["times"]]

        return DatasetItems(
            standard=DatasetStandardItems(
                dataparser_scale=dataparser_outputs.dataparser_scale,
                image_filenames=dataparser_outputs.image_filenames,
                depth_filenames=depth_filenames,
                depth_unit_scale_factor=depth_unit_scale_factor,
                times=times,
            ),
            camera=DatasetCameraItems(
                cameras=cameras,
                sample_to_camera_idx=sample_to_camera_idx,
                multiview_cam2worlds=multiview_cam2worlds,
                multiview_intrinsics=multiview_intrinsics,
                coordinates=coordinates,
            ),
            action=DatasetActionItems(
                num_joints=num_joints,
                active_joints=active_joints,
                keyname_to_qpos=keyname_to_qpos,
                qpos_minimum=qpos_minimum,
                qpos_maximum=qpos_maximum,
            ),
        )

    @staticmethod
    def random_select_action_type(
        curr_frame_idx: int, frame_displacement: int, max_num_frames: int = 8
    ) -> Literal["fwd", "bwd"]:
        if curr_frame_idx <= frame_displacement - 1:
            return "fwd"
        elif curr_frame_idx >= max_num_frames - frame_displacement:
            return "bwd"
        else:
            return random.choice(["fwd", "bwd"])

    def preprocess_qpos(self, qpos_items: QposItems) -> QposItems:
        """Dataset dependent, default to identity"""

        return qpos_items

    def load_robot_action(
        self,
        sample_idx: int,
        curr_frame_idx: int,
        next_frame_idx: int,
    ):
        ### load robot action
        curr_frame_keyname = f"{sample_idx:05d}_{curr_frame_idx:05d}"
        next_frame_keyname = f"{sample_idx:05d}_{next_frame_idx:05d}"

        curr_qpos = self.dataset_items.action.keyname_to_qpos[
            curr_frame_keyname
        ].clone()
        next_qpos = self.dataset_items.action.keyname_to_qpos[
            next_frame_keyname
        ].clone()

        qpos_items = self.preprocess_qpos(
            QposItems(
                curr_qpos=curr_qpos,
                next_qpos=next_qpos,
                qpos_minimum=self.dataset_items.action.qpos_minimum.clone(),
                qpos_maximum=self.dataset_items.action.qpos_maximum.clone(),
            )
        )
        curr_qpos, next_qpos, qpos_minimum, qpos_maximum = (
            qpos_items.curr_qpos,
            qpos_items.next_qpos,
            qpos_items.qpos_minimum,
            qpos_items.qpos_maximum,
        )

        curr_qpos = convention.normalize(
            curr_qpos,
            old_min=qpos_minimum,
            old_max=qpos_maximum,
            new_min=-1.0,
            new_max=1.0,
        )
        next_qpos = convention.normalize(
            next_qpos,
            old_min=qpos_minimum,
            old_max=qpos_maximum,
            new_min=-1.0,
            new_max=1.0,
        )

        # normalize [-2, 2] to [-1, 1]
        robot_action = (next_qpos - curr_qpos) / 2.0
        # extract only active joints
        robot_action = robot_action[self.dataset_items.action.active_joints]

        return robot_action

    def load_extrinsics(self, camera_idx: int):
        c2w = self.dataset_items.camera.multiview_cam2worlds[camera_idx].clone()
        c2w = convention.post_process_camera_to_world(c2w)

        return c2w

    def load_intrinsics(self, camera_idx: int) -> Tuple[torch.Tensor, Tuple[int, int]]:
        intrinsics = self.dataset_items.camera.multiview_intrinsics[
            camera_idx
        ].clone()  # [3, 3]

        # normalize intrinsics
        image_width = self.dataset_items.camera.cameras.width[camera_idx].clone()
        image_height = self.dataset_items.camera.cameras.height[camera_idx].clone()

        intrinsics[:2] /= torch.tensor([image_width, image_height])[:, None].float()

        return intrinsics, (image_height.item(), image_width.item())

    def load_depth(self, trgt_img_filename, trgt_cam_idx: int):
        trgt_depth_filename = Path(trgt_img_filename.replace("rgb", "depth"))
        height = int(self.dataset_items.camera.cameras.height[trgt_cam_idx])
        width = int(self.dataset_items.camera.cameras.width[trgt_cam_idx])

        depth_scale_factor = (
            self.dataset_items.standard.depth_unit_scale_factor
            * self._dataparser_outputs.dataparser_scale
        )
        trgt_depth_img = get_depth_image_from_path(
            filepath=trgt_depth_filename,
            height=height,
            width=width,
            scale_factor=depth_scale_factor,
        ).permute(2, 0, 1)

        return trgt_depth_img

    def load_action_mask(self, trgt_img_filename, trgt_cam_idx: int):
        trgt_mask_filename = Path(trgt_img_filename.replace("rgb", "mask"))
        mask = cv2.imread(trgt_mask_filename)
        # if mask:
        mask = mask.astype(bool)
        height = int(self.dataset_items.camera.cameras.height[trgt_cam_idx])
        width = int(self.dataset_items.camera.cameras.width[trgt_cam_idx])
        mask = torch.from_numpy(mask)

        # 将形状从 (H, W, C) 转换为 (C, H, W)
        mask = mask.permute(2, 0, 1)
        # else:
        #     print(trgt_mask_filename+" not exist")



        return mask

    @property
    def num_files(self) -> int:
        return len(self._dataparser_outputs.image_filenames)

    def __len__(self) -> int:
        return self.num_files * self.repeat

    @staticmethod
    def get_relative_transform(ctxt_c2w, trgt_c2w):
        inverse_ctxt_c2w = torch.inverse(ctxt_c2w)
        ctxt_c2w = torch.einsum("ij, jk -> ik", inverse_ctxt_c2w, ctxt_c2w)
        trgt_c2w = torch.einsum("ij, jk -> ik", inverse_ctxt_c2w, trgt_c2w)

        return ctxt_c2w, trgt_c2w

    def __getitem__(self, ctxt_file_idx: int):
        ctxt_file_idx = ctxt_file_idx % self.num_files

        if self.cfg.overfit_to_scene is not None:
            ctxt_file_idx = int(self.cfg.overfit_to_scene)

        ctxt_cam_idx = self.dataset_items.camera.sample_to_camera_idx[ctxt_file_idx]
        trgt_cam_idx = random.choice(range(len(self.dataset_items.camera.cameras)))

        ctxt_img_filename = self._dataparser_outputs.image_filenames[ctxt_file_idx]
        ##debug
        ctxt_cam_idx = int(ctxt_cam_idx)
        ##
        trgt_img_filename = convention.get_trgt_view_filename(
            str(ctxt_img_filename), ctxt_cam_idx, trgt_cam_idx
        )
        # trgt_img_filename = convention.get_trgt_view_filename(
        #     str(ctxt_img_filename), ctxt_cam_idx, trgt_cam_idx
        # )
        ###################
        ### process rgb ###
        ###################
        try:
            ctxt_rgb = io_utils.load_image_file_to_torch(
                ctxt_img_filename, self.scale_factor
            )
            trgt_rgb = io_utils.load_image_file_to_torch(
                trgt_img_filename, self.scale_factor
            )
        except OSError:
            print(misc.cyan(f"Error loading image: {ctxt_img_filename}"))
            return self.__getitem__(random.randint(0, self.num_files))

        image_height, image_width = ctxt_rgb.shape[-2:]

        ##########################
        ### process extrinsics ###
        ##########################
        ctxt_c2w = self.load_extrinsics(ctxt_cam_idx)
        trgt_c2w = self.load_extrinsics(trgt_cam_idx)
        inverse_ctxt_c2w = torch.inverse(ctxt_c2w)
        ctxt_c2w = torch.einsum("ij, jk -> ik", inverse_ctxt_c2w, ctxt_c2w)
        trgt_c2w = torch.einsum("ij, jk -> ik", inverse_ctxt_c2w, trgt_c2w)

        ##########################
        ### process intrinsics ###
        ##########################

        ctxt_intr, (render_height, render_width) = self.load_intrinsics(ctxt_cam_idx)
        trgt_intr, _ = self.load_intrinsics(trgt_cam_idx)

        #####################
        ### process depth ###
        #####################
        trgt_depth_img = self.load_depth(trgt_img_filename, trgt_cam_idx)

        ###########################
        ### process coordinates ###
        ###########################
        coordinates, _ = get_pixel_coordinates(render_height, render_width)

        ##### Augmentation
        if self.cfg.augment_ctxt_image:
            ctxt_rgb = self.augment_image(ctxt_rgb, ctxt_img_filename)

        if self.stage == "test" and self.zero_background is not None:
            ctxt_rgb = self.zero_background(ctxt_rgb)


        ##load_action_mask

        action_mask = self.load_action_mask(trgt_img_filename, trgt_cam_idx)
        currt_action_mask = self.load_action_mask(str(ctxt_img_filename), ctxt_cam_idx)






        ######################
        ## process actions ###
        ######################

        traj_idx, curr_frame_idx = convention.get_traj_and_frame_idx(
            trgt_img_filename
        )
        max_num_frames_per_traj = self.get_max_num_frames_per_traj(traj_idx)

        rand_frame_displacement = random.randint(1, self.cfg.max_frame_displacement)
        flow_type = self.random_select_action_type(
            curr_frame_idx=curr_frame_idx,
            frame_displacement=rand_frame_displacement,
            max_num_frames=max_num_frames_per_traj,
        )
        ### load next frame
        next_frame_idx = (
            curr_frame_idx + rand_frame_displacement
            if flow_type == "fwd"
            else curr_frame_idx - rand_frame_displacement
        )
        ### load action
        robot_action = self.load_robot_action(
            traj_idx, curr_frame_idx, next_frame_idx
        )



        tart_flow = self.load_optical_flow_supervision(
            trgt_img_filename, traj_idx, curr_frame_idx, flow_type
        )
        # tart_flow = add_zero_channel(resize_flow(tart_flow, 240, 320) * action_mask[0:2, :, :])
        tart_flow = resize_flow(tart_flow, 240, 320)
        #tart_flow = add_zero_channel(resize_flow(tart_flow, 240, 320) )


        input_flow = self.load_input_optical_flow_supervision(
            str(ctxt_img_filename), traj_idx, curr_frame_idx, flow_type
        )
        #input_flow = add_zero_channel(resize_flow(input_flow, 240, 320))
        input_flow = resize_flow(input_flow, 240, 320)
        # self.visualize_dataset_item(0, Path("output/"))









        data_dict = {
            "context": {
                "rgb": ctxt_rgb,
                "extrinsics": ctxt_c2w,
                "intrinsics": ctxt_intr,
                "robot_action": torch.zeros(
                    (len(self.dataset_items.action.active_joints),), dtype=torch.float32
                ),
                "action_mask":action_mask,
            },
            "target": {
                "rgb": trgt_rgb,
                "depth": trgt_depth_img*action_mask[0,:,:].unsqueeze(0),
                # "depth": trgt_depth_img ,
                "extrinsics": trgt_c2w,
                "intrinsics": trgt_intr,
                'flow':tart_flow,
            },
            "scene": {
                "near": self.get_bound("near", num_views=1),
                "far": self.get_bound("far", num_views=1),
                "coordinates": coordinates,
            },
            "index":{"input_cam_index":ctxt_cam_idx,
                     "tart_cam_index":trgt_cam_idx,
                     "scene_index":get_scene_index(ctxt_img_filename),




            }
        }

        # data_dict = {
        #     "context": {
        #         "rgb": input_flow,
        #         "extrinsics": ctxt_c2w,
        #         "intrinsics": ctxt_intr,
        #         "robot_action": torch.zeros(
        #             (len(self.dataset_items.action.active_joints),), dtype=torch.float32
        #         ),
        #         "action_mask":action_mask,
        #     },
        #     "target": {
        #         "rgb": trgt_rgb,
        #
        #         "depth": trgt_depth_img ,
        #         "extrinsics": trgt_c2w,
        #         "intrinsics": trgt_intr,
        #         'flow':tart_flow,
        #     },
        #     "scene": {
        #         "near": self.get_bound("near", num_views=1),
        #         "far": self.get_bound("far", num_views=1),
        #         "coordinates": coordinates,
        #     },
        #     "index":{"input_cam_index":ctxt_cam_idx,
        #              "tart_cam_index":trgt_cam_idx,
        #              "scene_index":get_scene_index(ctxt_img_filename),
        #
        #
        #     }
        # }

        data_dict["context"]["robot_action"] = robot_action
        # visualize_tensor_image(data_dict["context"]['rgb'],title="input_rgb")
        #
        # visualize_tensor_image(data_dict["context"]['action_mask'][0,:,:].unsqueeze(0),title="mask")
        # visualize_tensor_image(data_dict["target"]['rgb'],title="tart_rgb")
        # visualize_tensor_image(data_dict["target"]['flow'],title="tart_flow")
        #
        # print(data_dict["target"]['depth']*action_mask[0,:,:].unsqueeze(0).max())
        # visualize_tensor_image(data_dict["target"]['depth'],title="tart_depth")

        return data_dict

    def get_bound(
        self,
        bound: Literal["near", "far"],
        num_views: int,
    ):
        value = torch.tensor(getattr(self, bound), dtype=torch.float32)
        return value

    def augment_image(self, image: torch.Tensor, image_filename: Path):
        mask = str(image_filename).replace("rgb", "mask").replace(".png", ".npy")
        mask = torch.from_numpy(np.load(mask)).float()
        image = self.random_background(image, mask)
        return image

    def load_input_optical_flow_supervision(
        self,
        trgt_img_filename: str,
        traj_idx: int,
        curr_frame_idx: int,
        flow_type: Literal["fwd", "bwd"],
    ) -> Float[Tensor, "2 H W"]:
        trgt_optical_flow_filename = convention.get_optical_flow_filename(
            trgt_img_filename, traj_idx, curr_frame_idx, flow_type
        )
        trgt_optical_flow = io_utils.load_optical_flow(trgt_optical_flow_filename)
        trgt_optical_flow = torch.from_numpy(trgt_optical_flow).float()

        return trgt_optical_flow
    def load_optical_flow_supervision(
        self,
        trgt_img_filename: str,
        traj_idx: int,
        curr_frame_idx: int,
        flow_type: Literal["fwd", "bwd"],
    ) -> Float[Tensor, "2 H W"]:
        trgt_optical_flow_filename = convention.get_optical_flow_filename(
            trgt_img_filename, traj_idx, curr_frame_idx, flow_type
        )
        trgt_optical_flow = io_utils.load_optical_flow(trgt_optical_flow_filename)
        trgt_optical_flow = torch.from_numpy(trgt_optical_flow).float()

        return trgt_optical_flow

    def load_tracks_supervision(
        self,
        trgt_img_filename: str,
        traj_idx: int,
        curr_frame_idx: int,
        next_frame_idx: int,
        image_width: int = 640,
    ) -> TrackSupervision:
        tapir_track_data = io_utils.load_tapir_tracks(
            trgt_img_filename=trgt_img_filename,
            traj_idx=traj_idx,
            curr_frame_idx=curr_frame_idx,
            next_frame_idx=next_frame_idx,
            num_negative=self.cfg.num_negative_samples,
            num_positive=self.cfg.num_positive_samples,
        )

        # if tapir_track_data is False:
        #     return None

        point_track_data = tapir_track_data["point_track_data"]
        pixel_visible_mask = tapir_track_data["pixel_visible_mask"]
        negative_yx = tapir_track_data["negative_yx"]
        num_negative = len(negative_yx)

        curr_pos_x, curr_pos_y = point_track_data[:, curr_frame_idx, :].split(1, dim=-1)
        next_pos_x, next_pos_y = point_track_data[:, next_frame_idx, :].split(1, dim=-1)

        flow_x, flow_y = (next_pos_x - curr_pos_x), (next_pos_y - curr_pos_y)
        pixel_selector = torch.cat(
            [
                torch.cat([curr_pos_y, curr_pos_x], dim=-1),
                negative_yx,
            ],
            dim=0,
        )

        pixel_selector = torch.round(
            pixel_selector[:, 0] * image_width + pixel_selector[:, 1]
        ).long()

        pixel_motion = torch.cat(
            [
                torch.cat([flow_x, flow_y], dim=-1),
                torch.zeros_like(negative_yx),
            ],
            dim=0,
        )

        pixel_visible_mask = torch.cat(
            [
                pixel_visible_mask[:, next_frame_idx],
                torch.ones((num_negative,), dtype=torch.float32),
            ]
        )

        return TrackSupervision(
            pixel_selector=pixel_selector,
            pixel_motion=pixel_motion,
            pixel_visible_mask=pixel_visible_mask,
        )

    def get_max_num_frames_per_traj(self, traj_idx: int) -> int:
        return self.cfg.max_num_frames_per_traj



def get_scene_index(path: PosixPath) -> int:
    stem = path.stem  # 获取文件名不含扩展名，如 '00195_00004'
    a, b = stem.split('_')
    return int(a) * 10 + int(b)


def resize_flow(flow, target_height, target_width):
    """
    Resize flow tensor from (2, H, W) to (2, target_H, target_W)
    并相应调整光流值的大小
    """
    if flow.dim() == 3 and flow.shape[0] == 2:  # (2, H, W) - [u, v] 光流
        original_height, original_width = flow.shape[1], flow.shape[2]

        # 计算缩放因子
        scale_h = target_height / original_height
        scale_w = target_width / original_width

        # 插值resize
        flow_resized = torch.nn.functional.interpolate(
            flow.unsqueeze(0),
            size=(target_height, target_width),
            mode='bilinear',  # 对于光流通常使用双线性插值
            align_corners=False
        ).squeeze(0)

        # 调整光流值的大小
        # x方向光流 (u) 需要乘以宽度缩放因子
        flow_resized[0] *= scale_w  # flow_x
        # y方向光流 (v) 需要乘以高度缩放因子
        flow_resized[1] *= scale_h  # flow_y

        return flow_resized
    else:
        raise ValueError(f"Expected flow shape (2, H, W), got {flow.shape}")


def visualize_tensor_image(tensor, title="Tensor Image", figsize=(12, 4), save_path=None):
    """
    可视化tensor格式的(C, H, W)图像，根据通道数自动判断类型

    Args:
        tensor: torch.Tensor, shape (C, H, W)
        title: str, 图像标题
        figsize: tuple, 图像大小
        save_path: str or Path, 保存路径（可选）
    """
    if not isinstance(tensor, torch.Tensor):
        raise ValueError("Input must be a torch.Tensor")

    if tensor.dim() != 3:
        raise ValueError(f"Expected 3D tensor (C, H, W), got {tensor.dim()}D")

    C, H, W = tensor.shape

    # 转换为numpy并移动到CPU
    img_np = tensor.detach().cpu().numpy()

    if C == 1:  # 单通道 - 深度图或灰度图

        img_np = (img_np/img_np.max())*255
        img_np = img_np.astype(np.uint8)
        plt.figure(figsize=figsize)
        plt.imshow(img_np[0], cmap='viridis')  # 使用viridis colormap适合深度图
        plt.colorbar()
        plt.title(f"{title} - Depth/Grayscale (C={C}, H={H}, W={W})")
        plt.axis('off')

    elif C == 3:  # 三通道 - RGB图像
        # 确保数值在[0, 1]范围内
        img_np = np.clip(img_np, 0, 1)
        # 转换为(H, W, C)用于matplotlib
        img_np = np.transpose(img_np, (1, 2, 0))

        plt.figure(figsize=figsize)
        plt.imshow(img_np)
        plt.title(f"{title} - RGB (C={C}, H={H}, W={W})")
        plt.axis('off')

    elif C == 2:  # 双通道 - 光流
        # 光流可视化
        flow_u = img_np[0]  # u分量 (x方向)
        flow_v = img_np[1]  # v分量 (y方向)

        # 计算光流幅值和角度
        magnitude = np.sqrt(flow_u ** 2 + flow_v ** 2)
        angle = np.arctan2(flow_v, flow_u)  # 注意：flow_v是y分量，flow_u是x分量

        # 将角度从[-π, π]映射到[0, 180]，幅值归一化到[0, 255]
        angle_deg = (angle + np.pi) * 180 / (2 * np.pi)  # [0, 180]
        max_magnitude = np.max(magnitude)
        if max_magnitude > 0:
            magnitude_normalized = (magnitude / max_magnitude) * 255
        else:
            magnitude_normalized = magnitude

        # 创建HSV图像
        hsv = np.zeros((H, W, 3), dtype=np.uint8)
        hsv[:, :, 0] = angle_deg.astype(np.uint8)  # 色调(H) - 表示方向
        hsv[:, :, 1] = 255  # 饱和度(S) - 最大饱和度
        hsv[:, :, 2] = magnitude_normalized.astype(np.uint8)  # 亮度(V) - 表示幅值

        # 转换为BGR，然后转为RGB
        bgr = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
        rgb_flow = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)

        plt.figure(figsize=figsize)
        plt.imshow(rgb_flow)
        plt.title(f"{title} - Optical Flow (C={C}, H={H}, W={W})")
        plt.axis('off')

    else:  # 其他通道数 - 显示为多个子图
        num_cols = min(4, C)  # 最多4列
        num_rows = (C + num_cols - 1) // num_cols  # 计算需要的行数

        fig, axes = plt.subplots(num_rows, num_cols, figsize=(4 * num_cols, 4 * num_rows))
        if num_rows == 1 and num_cols == 1:
            axes = [axes]
        elif num_rows == 1 or num_cols == 1:
            axes = axes.flatten()
        else:
            axes = axes.flatten()

        for c in range(C):
            if c == 0:  # 第一个通道使用viridis colormap
                im = axes[c].imshow(img_np[c], cmap='viridis')
                plt.colorbar(im, ax=axes[c])
            else:  # 其他通道使用gray colormap
                axes[c].imshow(img_np[c], cmap='gray')
                plt.colorbar(axes[c].imshow(img_np[c], cmap='gray'), ax=axes[c])
            axes[c].set_title(f'Channel {c}')
            axes[c].axis('off')

        # 隐藏多余的子图
        for c in range(C, len(axes)):
            axes[c].axis('off')

        plt.suptitle(f"{title} - Multi-channel (C={C}, H={H}, W={W})")

    plt.tight_layout()

    if save_path is not None:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"Image saved to: {save_path}")

    plt.show()



def add_zero_channel(tensor):
    """
    将 (2, 1, 2, 240, 320) 的tensor添加一个全零通道变成 (2, 1, 3, 240, 320)
    新通道添加到最后一个通道位置
    """
    channels, height, width = tensor.shape

    # 创建一个形状为 (2, 1, 1, 240, 320) 的全零tensor
    zero_channel = torch.zeros(1, height, width, dtype=tensor.dtype, device=tensor.device)

    # 将原tensor和零通道在通道维度上连接
    result = torch.cat([tensor, zero_channel], dim=0)

    return result