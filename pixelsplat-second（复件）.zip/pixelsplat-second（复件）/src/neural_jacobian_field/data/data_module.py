from lightning.pytorch import LightningDataModule
from torch.utils.data import DataLoader
from typing import Dict
import torch
# from .dataset.dataset_toy_arm import DatasetToyArmPointTrack
from .dataset.dataset import DatasetCommon
from .dataset import DatasetAllegro
from .dataset.dataset_hsa import DatasetHsa
from .dataset.dataset_toy_arm import DatasetToyArm
from .dataset.dataset_pneumatic import DatasetPneumaticHandOnly
from .validation_wrapper import ValidationWrapper
from ..config.common import PipelineCfg
from src.config import RootCfg
from torch.utils.data import default_collate


def custom_collate_fn(batch):
    """
    将 DatasetCommon 的单样本 dict 转换为 ModelWrapper 期望的 BatchedExample
    """
    # 使用 default_collate 自动堆叠所有 tensor
    collated = default_collate(batch)

    # 重命名字段，并添加 batch 维度（C=1, V=1）
    result = {
        "context": {
            "image": collated["context"]["rgb"].unsqueeze(1),      # [B, 3, H, W] -> [B, 1, 3, H, W]
            "extrinsics": collated["context"]["extrinsics"].unsqueeze(1),  # [B, 4, 4] -> [B, 1, 4, 4]
            "intrinsics": collated["context"]["intrinsics"].unsqueeze(1),  # [B, 3, 3] -> [B, 1, 3, 3]
            "index": collated["index"]["input_cam_index"],
            "robot_action":collated["context"]["robot_action"].unsqueeze(1),
            "action_mask": collated["context"]["action_mask"].unsqueeze(1), # [B, 1]
        },
        "target": {
            "image": collated["target"]["rgb"].unsqueeze(1),       # [B, 3, H, W] -> [B, 1, 3, H, W]
            "extrinsics": collated["target"]["extrinsics"].unsqueeze(1),
            "intrinsics": collated["target"]["intrinsics"].unsqueeze(1),
            "depth":collated["target"]["depth"].unsqueeze(1),
            "near": collated["scene"]["near"].unsqueeze(1),        # [B] -> [B, 1]
            "far": collated["scene"]["far"].unsqueeze(1),
            "flow":collated["target"]["flow"].unsqueeze(1),# [B] -> [B, 1]
            "index": collated["index"]["tart_cam_index"],
        },
        "scene": collated["index"]["scene_index"],  # 或从 batch 中提取真实 scene name
    }

    return result
DATASETS = {
    "allegro": DatasetAllegro,
    "hsa": DatasetHsa,
    "toy_arm": DatasetToyArm,
    "pneumatic_hand_only": DatasetPneumaticHandOnly,
}

# def get_dataset(
#         cfg: DatasetCfg,
#
# )


class DataModule(LightningDataModule):
    # cfg: PipelineCfg

    # def __init__(self, cfg: PipelineCfg):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg


    def train_dataloader(self):
        return DataLoader(
            DATASETS[self.cfg.dataset.name](cfg=self.cfg.dataset, stage="train"),
            shuffle=True,
            batch_size=self.cfg.training.data.batch_size,
            num_workers=self.cfg.training.data.num_workers,
            collate_fn=custom_collate_fn
        )

    def val_dataloader(self):
        return DataLoader(
            ValidationWrapper(
                DATASETS[self.cfg.dataset.name](cfg=self.cfg.dataset, stage="val"),
                1,
            ),
            batch_size=self.cfg.validation.data.batch_size,
            num_workers=self.cfg.validation.data.num_workers,
            collate_fn=custom_collate_fn
        )

    def test_dataloader(self):
        return DataLoader(
            ValidationWrapper(
                DATASETS[self.cfg.dataset.name](cfg=self.cfg.dataset, stage="test"),
                1,
            ),
            batch_size=self.cfg.validation.data.batch_size,
            num_workers=self.cfg.validation.data.num_workers,
            collate_fn=custom_collate_fn
        )
