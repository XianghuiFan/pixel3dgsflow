from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple, List, Union


# ========================
# Wandb 配置
# ========================
@dataclass
class WandbCfg:
    project: str = "self-model"
    entity: str = "scene-representation-group"
    mode: str = "offline"
    name: str = "jacobian_fields"
    group: Optional[str] = None
    tags: Optional[List[str]] = None


# ========================
# 渲染配置（NeRF 风格，但我们会保留结构）
# ========================
@dataclass
class RenderingCfg:
    num_proposal_samples: Tuple[int, ...] = (256,)
    num_nerf_samples: int = 256
    single_jitter: bool = False
    proposal_warmup: int = 5000
    proposal_update_every: int = 5
    use_proposal_weight_anneal: bool = True
    proposal_weights_anneal_max_num_iters: int = 1000
    proposal_weights_anneal_slope: float = 10.0


# ========================
# MLP 配置
# ========================
@dataclass
class MlpCfg:
    n_blocks: int = 5
    d_hidden: int = 128
    combine_layer: int = 3
    combine_type: str = "mean"
    beta: float = 0.0


# ========================
# Encoder 配置（ResNet）
# ========================
@dataclass
class EncoderResnetCfg:
    name: str = "resnet"
    upsample_interp: str = "bilinear"
    num_layers: int = 4
    use_first_pool: bool = True
    norm_type: str = "batch"


# ========================
# Density Decoder 配置
# ========================
@dataclass
class DensityDecoderMlpCfg:
    name: str = "density_mlp"
    mlp: MlpCfg = MlpCfg(n_blocks=5, d_hidden=128, combine_layer=3, combine_type="mean", beta=0.0)
    num_frequencies: int = 10


# ========================
# Transformer 配置
# ========================
@dataclass
class TransformerCfg:
    attn_feat_dim: int = 48
    attn_head_dim: int = 48
    num_attn_heads: int = 6
    attn_depth: int = 3
    attn_mlp_dim: int = 48


# ========================
# Action Decoder 配置
# ========================
@dataclass
class ActionDecoderJacobianTransformerCfg:
    name: str = "jacobian_transformer"
    mlp: MlpCfg = MlpCfg(n_blocks=5, d_hidden=64, combine_layer=3, combine_type="mean", beta=0.0)
    transformer: TransformerCfg = TransformerCfg(
        attn_feat_dim=48,
        attn_head_dim=48,
        num_attn_heads=6,
        attn_depth=3,
        attn_mlp_dim=48,
    )
    num_frequencies: int = 10
    geometry_feature_dim: int = 15
    use_arm_model: bool = False
    arm_action_dim: Optional[int] = None


# ========================
# Model 配置
# ========================
@dataclass
class ModelCfg:
    action_dim: int = 4
    rendering: RenderingCfg = RenderingCfg()
    encoder: EncoderResnetCfg = EncoderResnetCfg()
    density_decoder: DensityDecoderMlpCfg = DensityDecoderMlpCfg()
    action_decoder: ActionDecoderJacobianTransformerCfg = ActionDecoderJacobianTransformerCfg()


# ========================
# Dataset 配置（Allegro）
# ========================
@dataclass
class DatasetAllegroCfg:
    name: str = "allegro"
    mode: str = "perception"
    overfit_to_scene: Optional[str] = None
    root: Union[str, Path] = "/srv/njf/jnerf/datasets--sizhe-lester-li--neural-jacobian-field-allegro-only/snapshots/allegro/allegro_mini2"
    other_roots: Optional[List[Union[str, Path]]] = None
    num_total_joints: int = 16
    disabled_joints: List[int] = (0, 1, 2, 3, 4, 5, 6, 7,8,9,10,11)  # 注意：dataclass 中用 tuple 更安全
    max_frame_displacement: int = 1
    max_num_frames_per_traj: int = 10
    action_supervision_type: str = "optical_flow"
    num_positive_samples: int = 256
    num_negative_samples: int = 256
    augment_ctxt_image: bool = False
    testing_mask_ratio: Optional[float] = None


# ========================
# Dataloader 配置
# ========================
@dataclass
class DataloaderCfg:
    rays_per_batch: int = 320
    batch_size: int = 1
    num_workers: int = 0


# ========================
# Optimizer 配置
# ========================
@dataclass
class OptimizerCfg:
    lr: float = 0.0001
    warm_up_steps: int = 10000


# ========================
# Training 配置
# ========================
@dataclass
class TrainingCfg:
    data: DataloaderCfg = DataloaderCfg(rays_per_batch=320, batch_size=1, num_workers=16)
    optim: OptimizerCfg = OptimizerCfg(lr=0.0001, warm_up_steps=10000)
    val_check_interval: int = 30000
    max_steps: int = 50000000


# ========================
# Validation Video 配置
# ========================
@dataclass
class ValidationVideoCfg:
    frequency: float = 0.25
    num_frames: int = 5
    frame_rate: int = 5


# ========================
# Validation 配置
# ========================
@dataclass
class ValidationCfg:
    data: DataloaderCfg = DataloaderCfg(rays_per_batch=128, batch_size=1, num_workers=4)
    video: ValidationVideoCfg = ValidationVideoCfg(frequency=0.25, num_frames=5, frame_rate=5)


# ========================
# Checkpoint 配置
# ========================
@dataclass
class CheckpointCfg:
    every_n_train_steps: int = 30000
    load: Optional[str] = None


# ========================
# 顶层 Pipeline 配置
# ========================
@dataclass
class allegroCfg:
    wandb: WandbCfg = WandbCfg()
    model: ModelCfg = ModelCfg()
    dataset: DatasetAllegroCfg = DatasetAllegroCfg()
    training: TrainingCfg = TrainingCfg()
    validation: ValidationCfg = ValidationCfg()
    checkpoint: CheckpointCfg = CheckpointCfg()