from dataclasses import dataclass
from typing import Literal, Optional

import torch
from einops import rearrange
from jaxtyping import Float
from torch import Tensor, nn

from ...dataset.shims.bounds_shim import apply_bounds_shim
from ...dataset.shims.patch_shim import apply_patch_shim
from ...dataset.types import BatchedExample, DataShim
from ...geometry.projection import sample_image_grid
from ..types import Gaussians
from .backbone import Backbone, BackboneCfg, get_backbone
from .common.gaussian_adapter import GaussianAdapter, GaussianAdapterCfg
from .encoder import Encoder
from .epipolar.depth_predictor_monocular import DepthPredictorMonocular
from .epipolar.epipolar_transformer import EpipolarTransformer, EpipolarTransformerCfg
from .visualization.encoder_visualizer_epipolar_cfg import EncoderVisualizerEpipolarCfg
from ..decoder.Resnet_fc import JacobianHead

@dataclass
class OpacityMappingCfg:
    initial: float
    final: float
    warm_up: int

@dataclass
class EncoderEpipolarCfg:
    name: Literal["epipolar"]
    d_feature: int
    num_monocular_samples: int
    num_surfaces: int
    predict_opacity: bool
    backbone: BackboneCfg
    visualizer: EncoderVisualizerEpipolarCfg
    near_disparity: float
    gaussian_adapter: GaussianAdapterCfg
    apply_bounds_shim: bool
    epipolar_transformer: EpipolarTransformerCfg
    opacity_mapping: OpacityMappingCfg
    gaussians_per_pixel: int
    use_epipolar_transformer: bool
    use_transmittance: bool
    use_action_embedding: bool = True  # 新增配置项
    # --- 新增动作融合配置 ---
    action_fusion_type: Literal["film", "add", "concat", "attention"] = "film" # 选择融合方式
    action_embed_dim: int = 128 # 动作嵌入维度
    # --- 新增配置结束 ---


class EncoderEpipolar(Encoder[EncoderEpipolarCfg]):
    backbone: Backbone
    backbone_projection: nn.Sequential
    epipolar_transformer: EpipolarTransformer | None
    depth_predictor: DepthPredictorMonocular
    to_gaussians: nn.Sequential
    gaussian_adapter: GaussianAdapter
    high_resolution_skip: nn.Sequential
    actionembedding: nn.Module | None  # 使用更通用的类型
    # --- 新增融合模块 ---
    action_fusion_module: nn.Module | None
    # --- 新增模块结束 ---

    def __init__(self, cfg: EncoderEpipolarCfg) -> None:
        super().__init__(cfg)
        self.action = True
        self.cfg = cfg

        # 创建网络组件
        self.backbone = get_backbone(cfg.backbone, 3)
        # --- 修改 backbone_projection 以适应可能的融合 ---
        # 假设融合后的维度仍然是 d_feature，或者根据融合方式调整
        self.backbone_projection = nn.Sequential(
            nn.ReLU(),
            # 如果融合后维度变化，这里需要调整
            nn.Linear(512, cfg.d_feature),
        )
        # --- 修改结束 ---

        if cfg.use_epipolar_transformer:
            self.epipolar_transformer = EpipolarTransformer(
                cfg.epipolar_transformer,
                cfg.d_feature, # 确保输入维度与融合后一致
            )
        else:
            self.epipolar_transformer = None
        self.depth_predictor = DepthPredictorMonocular(
            cfg.d_feature, # 确保输入维度与融合后一致
            cfg.num_monocular_samples,
            cfg.num_surfaces,
            cfg.use_transmittance,
        )
        self.gaussian_adapter = GaussianAdapter(cfg.gaussian_adapter)
        if cfg.predict_opacity:
            self.to_opacity = nn.Sequential(
                nn.ReLU(),
                nn.Linear(cfg.d_feature, 1), # 确保输入维度与融合后一致
                nn.Sigmoid(),
            )
        # --- 修改 to_gaussians 输入维度 ---
        to_gaussians_input_dim = cfg.d_feature # 确保输入维度与融合后一致
        self.to_gaussians = nn.Sequential(
            nn.ReLU(),
            nn.Linear(
                to_gaussians_input_dim,
                cfg.num_surfaces * (2 + self.gaussian_adapter.d_in),
            ),
        )
        # --- 修改结束 ---
        self.high_resolution_skip = nn.Sequential(
            nn.Conv2d(3, cfg.d_feature, 7, 1, 3), # 确保输出维度与融合后一致
            nn.ReLU(),
        )

        # 添加actionembedding模块
        if self.action:
            self.jacobianhead = JacobianHead(input_dim=128, output_groups=4, output_features=9)
            # 动作嵌入模块
            # self.actionembedding = nn.Sequential(

        else:
            self.actionembedding = None
            self.action_fusion_module = None
            self.action_fusion_type = None

    # ... (保持 freeze_other_parameters, unfreeze_all_parameters, map_pdf_to_opacity 方法不变) ...



    def forward(
            self,
            context: dict,
            global_step: int,
            deterministic: bool = False,
            visualization_dump: Optional[dict] = None,
    ) :

        device = context["image"].device
        b, v, _, h, w = context["image"].shape

        # Encode the context images.
        features = self.backbone(context) # Shape: (B, V, C_backbone, H, W)





        # --- Apply backbone_projection after fusion ---
        features = rearrange(features, "b v c h w -> b v h w c")
        features = self.backbone_projection(features) # This handles the input dim change for 'concat'
        features = rearrange(features, "b v h w c -> b v c h w")

        # Run the epipolar transformer.
        if self.cfg.use_epipolar_transformer:
            features, sampling = self.epipolar_transformer(
                features,
                context["extrinsics"],
                context["intrinsics"],
                context["near"],
                context["far"],
            )

        # Add the high-resolution skip connection.
        skip = rearrange(context["image"], "b v c h w -> (b v) c h w")
        skip = self.high_resolution_skip(skip)
        features = features + rearrange(skip, "(b v) c h w -> b v c h w", b=b, v=v)

        # Sample depths from the resulting features.
        features = rearrange(features, "b v c h w -> b v (h w) c")

        ##
        if self.action:
            if 'robot_action' in context:
                action = context['robot_action']  # Shape: (B, V, 4) or (B, 1, 4) depending on your data
                if action.shape[1] == 1:
                     action = action.expand(-1, v, -1) # Expand if action is shared across views
                # 将action嵌入到特征空间


                mean3D_delta = self.apply_action_fusion(features,action)

                # Shape: (B, V, action_embed_dim)

                # Apply the selected fusion mechanism
# Shape: (B, V, C_fused, H, W)
#                 print(mean3D_delta.sum())

            else:
                raise ValueError("Action not found in context when use_action_embedding is True")


        depths, densities = self.depth_predictor.forward(
            features,
            context["near"],
            context["far"],
            deterministic,
            1 if deterministic else self.cfg.gaussians_per_pixel,
        )

        # Convert the features and depths into Gaussians.
        xy_ray, _ = sample_image_grid((h, w), device)
        xy_ray = rearrange(xy_ray, "h w xy -> (h w) () xy")
        gaussians = rearrange(
            self.to_gaussians(features),
            "... (srf c) -> ... srf c",
            srf=self.cfg.num_surfaces,
        )
        offset_xy = gaussians[..., :2].sigmoid()
        pixel_size = 1 / torch.tensor((w, h), dtype=torch.float32, device=device)
        xy_ray = xy_ray + (offset_xy - 0.5) * pixel_size
        gpp = self.cfg.gaussians_per_pixel
        gaussians = self.gaussian_adapter.forward(
            rearrange(context["extrinsics"], "b v i j -> b v () () () i j"),
            rearrange(context["intrinsics"], "b v i j -> b v () () () i j"),
            rearrange(xy_ray, "b v r srf xy -> b v r srf () xy"),
            depths,
            self.map_pdf_to_opacity(densities, global_step) / gpp,
            rearrange(gaussians[..., 2:], "b v r srf c -> b v r srf () c"),
            (h, w),
        )

        # Dump visualizations if needed.
        if visualization_dump is not None:
            visualization_dump["depth"] = rearrange(
                depths, "b v (h w) srf s -> b v h w srf s", h=h, w=w
            )
            visualization_dump["scales"] = rearrange(
                gaussians.scales, "b v r srf spp xyz -> b (v r srf spp) xyz"
            )
            visualization_dump["rotations"] = rearrange(
                gaussians.rotations, "b v r srf spp xyzw -> b (v r srf spp) xyzw"
            )
            if self.cfg.use_epipolar_transformer:
                visualization_dump["sampling"] = sampling

        # Optionally apply a per-pixel opacity.
        opacity_multiplier = (
            rearrange(self.to_opacity(features), "b v r () -> b v r () ()")
            if self.cfg.predict_opacity
            else 1
        )



        if self.action and not deterministic:

            current_gaussians = Gaussians(
                rearrange(
                    gaussians.means,
                    "b v r srf spp xyz -> b (v r srf spp) xyz",
                ),
                rearrange(
                    gaussians.covariances,
                    "b v r srf spp i j -> b (v r srf spp) i j",
                ),
                rearrange(
                    gaussians.harmonics,
                    "b v r srf spp c d_sh -> b (v r srf spp) c d_sh",
                ),
                rearrange(
                    opacity_multiplier * gaussians.opacities,
                    "b v r srf spp -> b (v r srf spp)",
                ),
            )


            currentmean = rearrange(gaussians.means,"b v r srf spp xyz -> b (v r srf spp) xyz",)
            mean3D_delta = mean3D_delta.squeeze(1)
            next_mean = currentmean+mean3D_delta
            # currentmean=currentmean
            next_gaussians = Gaussians(
                next_mean,
                rearrange(
                    gaussians.covariances,
                    "b v r srf spp i j -> b (v r srf spp) i j",
                ),
                rearrange(
                    gaussians.harmonics,
                    "b v r srf spp c d_sh -> b (v r srf spp) c d_sh",
                ),
                rearrange(
                    opacity_multiplier * gaussians.opacities,
                    "b v r srf spp -> b (v r srf spp)",
                ),
            )


            return current_gaussians,next_gaussians

        else:
            current_gaussians = Gaussians(
                rearrange(
                    gaussians.means,
                    "b v r srf spp xyz -> b (v r srf spp) xyz",
                ),
                rearrange(
                    gaussians.covariances,
                    "b v r srf spp i j -> b (v r srf spp) i j",
                ),
                rearrange(
                    gaussians.harmonics,
                    "b v r srf spp c d_sh -> b (v r srf spp) c d_sh",
                ),
                rearrange(
                    opacity_multiplier * gaussians.opacities,
                    "b v r srf spp -> b (v r srf spp)",
                ),
            )

            return current_gaussians

        return
    def map_pdf_to_opacity(
        self,
        pdf: Float[Tensor, " *batch"],
        global_step: int,
    ) -> Float[Tensor, " *batch"]:
        # https://www.desmos.com/calculator/opvwti3ba9

        # Figure out the exponent.
        cfg = self.cfg.opacity_mapping
        x = cfg.initial + min(global_step / cfg.warm_up, 1) * (cfg.final - cfg.initial)
        exponent = 2**x

        # Map the probability density to an opacity.
        return 0.5 * (1 - (1 - pdf) ** exponent + pdf ** (1 / exponent))
    # ... (保持 get_data_shim, sampler 属性不变) ...
    def get_data_shim(self) -> DataShim:
        def data_shim(batch: BatchedExample) -> BatchedExample:
            batch = apply_patch_shim(
                batch,
                patch_size=self.cfg.epipolar_transformer.self_attention.patch_size
                           * self.cfg.epipolar_transformer.downscale,
            )

            if self.cfg.apply_bounds_shim:
                _, _, _, h, w = batch["context"]["image"].shape
                near_disparity = self.cfg.near_disparity * min(h, w)
                batch = apply_bounds_shim(batch, near_disparity, 0.5)

            return batch

        return data_shim

    @property
    def sampler(self):
        # hack to make the visualizer work
        return self.epipolar_transformer.epipolar_sampler

    def apply_action_fusion(self, features: Tensor, action_embed: Tensor) -> Tensor:
        """
        Applies the selected action fusion mechanism.

        Args:
            features: Image features of shape (B, V, C, H, W).
            action_embed: Action embedding of shape (B, V, action_embed_dim) or (B, 1, action_embed_dim).

        Returns:
            Fused features of shape (B, V, C, H, W).
        """

        jacobian = self.jacobianhead(features)
        print(jacobian.sum())
        # mean_detla = torch.einsum('b n h k c, b k -> b n h c', jacobian, action_embed)
        mean_delta = torch.einsum('b n h k c, b n k -> b n h c', jacobian, action_embed)
        B, N, HW, C = mean_delta.shape  # B, 1, 76800, 9

        # 重新组织数据的顺序
        # 将 (B, 1, 76800, 9) -> (B, 1, 76800, 3, 3) -> (B, 1, 76800*3, 3) -> (B, 1, 230400, 3)
        tensor_reshaped = mean_delta.view(B, N, HW, 3, 3)  # (B, 1, 76800, 3, 3)
        result = tensor_reshaped.view(B, N, HW * 3, 3)
        return result