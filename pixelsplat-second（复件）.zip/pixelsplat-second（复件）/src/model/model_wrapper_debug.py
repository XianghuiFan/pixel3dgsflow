from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Protocol, runtime_checkable
import numpy as np
import moviepy.editor as mpy
import torch
import wandb
from einops import pack, rearrange, repeat
from jaxtyping import Float
from lightning.pytorch import LightningModule
from lightning.pytorch.loggers.wandb import WandbLogger
from lightning.pytorch.utilities import rank_zero_only
from torch import Tensor, nn, optim

from ..dataset.data_module import get_data_shim
from ..dataset.types import BatchedExample
from ..evaluation.metrics import compute_lpips, compute_psnr, compute_ssim
from ..global_cfg import get_cfg
from ..loss import Loss
from ..misc.benchmarker import Benchmarker
from ..misc.image_io import prep_image, save_image
from ..misc.LocalLogger import LOG_PATH, LocalLogger
from ..misc.step_tracker import StepTracker
from ..visualization.annotation import add_label
from ..visualization.camera_trajectory.interpolation import (
    interpolate_extrinsics,
    interpolate_intrinsics,
)
from ..visualization.camera_trajectory.wobble import (
    generate_wobble,
    generate_wobble_transformation,
)
from ..visualization.color_map import apply_color_map_to_image
from ..visualization.layout import add_border, hcat, vcat
from ..visualization.validation_in_3d import render_cameras, render_projections
from .decoder.decoder import Decoder, DepthRenderingMode
from .encoder import Encoder
from .encoder.visualization.encoder_visualizer import EncoderVisualizer
from ..scripts.compute_flow_from_gs import  calculate_predicted_flow
import cv2
@dataclass
class OptimizerCfg:
    lr: float
    warm_up_steps: int


@dataclass
class TestCfg:
    output_path: Path


@dataclass
class TrainCfg:
    depth_mode: DepthRenderingMode | None
    extended_visualization: bool


@runtime_checkable
class TrajectoryFn(Protocol):
    def __call__(
        self,
        t: Float[Tensor, " t"],
    ) -> tuple[
        Float[Tensor, "batch view 4 4"],  # extrinsics
        Float[Tensor, "batch view 3 3"],  # intrinsics
    ]:
        pass


class ModelWrapper(LightningModule):
    logger: Optional[WandbLogger]
    encoder: nn.Module
    encoder_visualizer: Optional[EncoderVisualizer]
    decoder: Decoder
    losses: nn.ModuleList
    optimizer_cfg: OptimizerCfg
    test_cfg: TestCfg
    train_cfg: TrainCfg
    step_tracker: StepTracker | None

    def __init__(
        self,
        optimizer_cfg: OptimizerCfg,
        test_cfg: TestCfg,
        train_cfg: TrainCfg,
        encoder: Encoder,
        encoder_visualizer: Optional[EncoderVisualizer],
        decoder: Decoder,
        losses: list[Loss],
        step_tracker: StepTracker | None,
    ) -> None:
        super().__init__()
        self.optimizer_cfg = optimizer_cfg
        self.test_cfg = test_cfg
        self.train_cfg = train_cfg
        self.step_tracker = step_tracker

        # Set up the model.
        self.encoder = encoder
        self.encoder_visualizer = encoder_visualizer
        self.decoder = decoder
        self.data_shim = get_data_shim(self.encoder)
        self.losses = nn.ModuleList(losses)
        # load_partial_pretrained(self.encoder, '/srv/download/pixelsplat-second/epoch=0-step=20000.ckpt')
        # This is used for testing.
        self.benchmarker = Benchmarker()

    def training_step(self, batch, batch_idx):
        batch: BatchedExample = self.data_shim(batch)
        _, _, _, h, w = batch["target"]["image"].shape

        # print("Batch scene:", batch["scene"])
        # print("Context index:", batch["context"]["index"].flatten())

        ##debug range fix
        batch["target"]["near"] = torch.full_like(batch["target"]["near"], 0.5)
        batch["target"]["far"] = torch.full_like(batch["target"]["far"], 10.0)
        batch["context"]["near"] = torch.full_like(batch["target"]["near"], 0.5)
        batch["context"]["far"] = torch.full_like(batch["target"]["far"], 10.0)

        # Run the model.



        gaussians,next_gaussians = self.encoder(batch["context"], self.global_step, False)

        output,items_for_flow = self.decoder.forward(
            gaussians,
            batch["target"]["extrinsics"],
            batch["target"]["intrinsics"],
            batch["target"]["near"],
            batch["target"]["far"],
            (h, w),
            depth_mode=self.train_cfg.depth_mode,
        )


        output_next,items_for_flow_next = self.decoder.forward(
            next_gaussians,
            batch["target"]["extrinsics"],
            batch["target"]["intrinsics"],
            batch["target"]["near"],
            batch["target"]["far"],
            (h, w),
            depth_mode=self.train_cfg.depth_mode,
        )

        batch["flow"] = calculate_predicted_flow(items_for_flow,items_for_flow_next)




        target_gt = batch["target"]["image"]

        # Compute metrics.
        psnr_probabilistic = compute_psnr(
            rearrange(target_gt, "b v c h w -> (b v) c h w"),
            rearrange(output.color, "b v c h w -> (b v) c h w"),
        )
        self.log("train/psnr_probabilistic", psnr_probabilistic.mean())

        # Compute and log loss.
        total_loss = 0
        for loss_fn in self.losses:
            loss = loss_fn.forward(output, batch, gaussians, self.global_step)
            self.log(f"loss/{loss_fn.name}", loss)
            total_loss = total_loss + loss
        self.log("loss/total", total_loss)

        # if self.global_rank == 0:
        #     print(
        #         f"train step {self.global_step}; "
        #         f"scene = {batch['scene']}; "
        #         f"context = {batch['context']['index'].tolist()}; "
        #         f"loss = {total_loss:.6f}"
        #     )
        if self.global_rank == 0 and self.global_step % 100 == 0:
            print(
                f"train step {self.global_step}; "
                f"scene = {batch['scene']}; "
                f"context = {batch['context']['index'].tolist()}; "
                f"loss = {total_loss:.6f}"
            )


        # Tell the data loader processes about the current step.
        if self.step_tracker is not None:
            self.step_tracker.set_step(self.global_step)

        return total_loss

    def test_step(self, batch, batch_idx):
        batch: BatchedExample = self.data_shim(batch)

        batch["target"]["near"] = torch.full_like(batch["target"]["near"], 0.5)
        batch["target"]["far"] = torch.full_like(batch["target"]["far"], 10.0)
        batch["context"]["near"] = torch.full_like(batch["target"]["near"], 0.5)
        batch["context"]["far"] = torch.full_like(batch["target"]["far"], 10.0)

        b, v, _, h, w = batch["target"]["image"].shape
        assert b == 1
        if batch_idx % 100 == 0:
            print(f"Test step {batch_idx:0>6}.")

        # Render Gaussians.
        with self.benchmarker.time("encoder"):
            gaussians = self.encoder(
                batch["context"],
                self.global_step,
                deterministic=False,
            )
        with self.benchmarker.time("decoder", num_calls=v):
            color = []
            for i in range(0, batch["target"]["far"].shape[1], 32):
                output,_ = self.decoder.forward(
                    gaussians,
                    batch["target"]["extrinsics"][:1, i : i + 32],
                    batch["target"]["intrinsics"][:1, i : i + 32],
                    batch["target"]["near"][:1, i : i + 32],
                    batch["target"]["far"][:1, i : i + 32],
                    (h, w),
                )
                color.append(output.color)
            color = torch.cat(color, dim=1)

        # Save images.
        (scene,) = batch["scene"]
        name = get_cfg()["wandb"]["name"]
        path = self.test_cfg.output_path / name
        for index, color in zip(batch["target"]["index"][0], color[0]):
            save_image(color, path / scene / f"color/{index:0>6}.png")
        for index, color in zip(
            batch["context"]["index"][0], batch["context"]["image"][0]
        ):
            save_image(color, path / scene / f"context/{index:0>6}.png")

    def on_test_end(self) -> None:
        name = get_cfg()["wandb"]["name"]
        self.benchmarker.dump(self.test_cfg.output_path / name / "benchmark.json")
        self.benchmarker.dump_memory(
            self.test_cfg.output_path / name / "peak_memory.json"
        )

    @rank_zero_only
    def validation_step(self, batch, batch_idx):
        batch: BatchedExample = self.data_shim(batch)
        ##debug range fix
        batch["target"]["near"] = torch.full_like(batch["target"]["near"], 0.5)
        batch["target"]["far"] = torch.full_like(batch["target"]["far"], 10.0)
        batch["context"]["near"] = torch.full_like(batch["target"]["near"], 0.5)
        batch["context"]["far"] = torch.full_like(batch["target"]["far"], 10.0)

        if self.global_rank == 0:
            print(
                f"validation step {self.global_step}; "
                f"scene = {batch['scene']}; "
                f"context = {batch['context']['index'].tolist()}"
            )

        # Render Gaussians.
        b, _, _, h, w = batch["target"]["image"].shape
        assert b == 1
        gaussians_probabilistic,_ = self.encoder(
            batch["context"],
            self.global_step,
            deterministic=False,
        )
        output_probabilistic,_ = self.decoder.forward(
            gaussians_probabilistic,
            batch["target"]["extrinsics"],
            batch["target"]["intrinsics"],
            batch["target"]["near"],
            batch["target"]["far"],
            (h, w),
        )





        rgb_probabilistic = output_probabilistic.color[0]
        gaussians_deterministic = self.encoder(
            batch["context"],
            self.global_step,
            deterministic=True,
        )
        # output_deterministic,_ = self.decoder.forward(
        #     gaussians_deterministic,
        #     batch["target"]["extrinsics"],
        #     batch["target"]["intrinsics"],
        #     batch["target"]["near"],
        #     batch["target"]["far"],
        #     (h, w),
        # )
        # rgb_deterministic = output_deterministic.color[0]

        # Compute validation metrics.
        rgb_gt = batch["target"]["image"][0]
        # for tag, rgb in zip(
        #         ("probabilistic"), ( rgb_probabilistic)
        # ):
        #     psnr = compute_psnr(rgb_gt, rgb).mean()
        #     self.log(f"val/psnr_{tag}", psnr)
        #     lpips = compute_lpips(rgb_gt, rgb).mean()
        #     self.log(f"val/lpips_{tag}", lpips)
        #     ssim = compute_ssim(rgb_gt, rgb).mean()
        #     self.log(f"val/ssim_{tag}", ssim)

        # Construct comparison image.
        # 修复：正确处理图像列表
        # ctxt_imgs = [img.squeeze(0) if img.dim() == 4 else img for img in batch["context"]["image"][0]]
        # gt_imgs = [img.squeeze(0) if img.dim() == 4 else img for img in batch["target"]["image"][0]]
        # rgb_prob_imgs = [img.squeeze(0) if img.dim() == 4 else img for img in rgb_probabilistic]
        # rgb_det_imgs = [img.squeeze(0) if img.dim() == 4 else img for img in rgb_deterministic]

        ctxt_imgs = [img.squeeze(0) if img.dim() == 4 else img for img in batch["context"]["image"][0]]
        gt_imgs = [
            img.squeeze(0) if img.dim() == 4 else img
            for img in batch["target"]["image"][0]]



        # rgb_prob_imgs = [img.squeeze(0) if img.dim() == 4 else img for img in rgb_probabilistic]
        # rgb_det_imgs = [img.squeeze(0) if img.dim() == 4 else img for img in rgb_deterministic]

        # 应用后处理
        rgb_prob_imgs = [
           img.squeeze(0) if img.dim() == 4 else img
            for img in rgb_probabilistic
        ]
        # rgb_det_imgs = [
        #     img.squeeze(0) if img.dim() == 4 else img
        #     for img in rgb_deterministic
        # ]




        # 构建比较图像 - 修复这里的拼接逻辑
        comparison_parts = []

        # Context images
        if len(ctxt_imgs) > 0:
            ctxt_comparison = add_label(vcat(*ctxt_imgs), "Context")
            comparison_parts.append(ctxt_comparison)

        # Ground truth images
        if len(gt_imgs) > 0:
            gt_comparison = add_label(vcat(gt_imgs), "Target (Ground Truth)")
            comparison_parts.append(gt_comparison)

        # Probabilistic results
        if len(rgb_prob_imgs) > 0:
            prob_comparison = add_label(vcat(rgb_prob_imgs), "Target (Probabilistic)")
            comparison_parts.append(prob_comparison)

        # # Deterministic results
        # if len(rgb_det_imgs) > 0:
        #     det_comparison = add_label(vcat(rgb_det_imgs), "Target (Deterministic)")
        #     comparison_parts.append(det_comparison)

        # 只有当有多个部分时才进行水平拼接
        if len(comparison_parts) > 1:
            comparison = hcat(comparison_parts)
        else:
            comparison = comparison_parts[0] if comparison_parts else None

        # if comparison is not None:
        #     self.logger.log_image(
        #         "comparison",
        #         [prep_image(add_border(comparison))],
        #         step=self.global_step,
        #         caption=batch["scene"],
        #     )
        # 水平拼接所有部分
        if len(comparison_parts) > 0:
            comparison = hcat(comparison_parts)
            self.logger.log_image(
                "comparison",
                [prep_image(add_border(comparison))],
                step=self.global_step,
                caption=batch["scene"],
            )

        # Render projections and construct projection image.
        # These are disabled for now, since RE10k scenes are effectively unbounded.

        pro_projections = [*render_projections(gaussians_probabilistic,256,extra_label="(Probabilistic)",)[0]]
        # deter_projections =  [*render_projections(gaussians_deterministic, 256, extra_label="(Deterministic)" )[0]]
        projections = hcat(
                pro_projections
            )

        self.logger.log_image(
            "projection",
            [prep_image(add_border(projections))],
            step=self.global_step,
        )

        # Draw cameras.
        cameras = hcat([*render_cameras(batch, 256)])
        self.logger.log_image(
            "cameras", [prep_image(add_border(cameras))], step=self.global_step
        )

        if self.encoder_visualizer is not None:
            for k, image in self.encoder_visualizer.visualize(
                    batch["context"], self.global_step
            ).items():
                self.logger.log_image(k, [prep_image(image)], step=self.global_step)

        # Run video validation step.
        self.render_video_interpolation(batch)
        self.render_video_wobble(batch)
        if self.train_cfg.extended_visualization:
            self.render_video_interpolation_exaggerated(batch)


    @rank_zero_only
    def render_video_wobble(self, batch: BatchedExample) -> None:
        # Two views are needed to get the wobble radius.
        _, v, _, _ = batch["context"]["extrinsics"].shape
        if v != 2:
            return

        def trajectory_fn(t):
            origin_a = batch["context"]["extrinsics"][:, 0, :3, 3]
            origin_b = batch["context"]["extrinsics"][:, 1, :3, 3]
            delta = (origin_a - origin_b).norm(dim=-1)
            extrinsics = generate_wobble(
                batch["context"]["extrinsics"][:, 0],
                delta * 0.25,
                t,
            )
            intrinsics = repeat(
                batch["context"]["intrinsics"][:, 0],
                "b i j -> b v i j",
                v=t.shape[0],
            )
            return extrinsics, intrinsics

        return self.render_video_generic(batch, trajectory_fn, "wobble", num_frames=60)

    @rank_zero_only
    def render_video_interpolation(self, batch: BatchedExample) -> None:
        _, v, _, _ = batch["context"]["extrinsics"].shape

        def trajectory_fn(t):
            extrinsics = interpolate_extrinsics(
                batch["context"]["extrinsics"][0, 0],
                (
                    batch["context"]["extrinsics"][0, 1]
                    if v == 2
                    else batch["target"]["extrinsics"][0, 0]
                ),
                t,
            )
            intrinsics = interpolate_intrinsics(
                batch["context"]["intrinsics"][0, 0],
                (
                    batch["context"]["intrinsics"][0, 1]
                    if v == 2
                    else batch["target"]["intrinsics"][0, 0]
                ),
                t,
            )
            return extrinsics[None], intrinsics[None]

        return self.render_video_generic(batch, trajectory_fn, "rgb")

    @rank_zero_only
    def render_video_interpolation_exaggerated(self, batch: BatchedExample) -> None:
        # Two views are needed to get the wobble radius.
        _, v, _, _ = batch["context"]["extrinsics"].shape
        if v != 2:
            return

        def trajectory_fn(t):
            origin_a = batch["context"]["extrinsics"][:, 0, :3, 3]
            origin_b = batch["context"]["extrinsics"][:, 1, :3, 3]
            delta = (origin_a - origin_b).norm(dim=-1)
            tf = generate_wobble_transformation(
                delta * 0.5,
                t,
                5,
                scale_radius_with_t=False,
            )
            extrinsics = interpolate_extrinsics(
                batch["context"]["extrinsics"][0, 0],
                (
                    batch["context"]["extrinsics"][0, 1]
                    if v == 2
                    else batch["target"]["extrinsics"][0, 0]
                ),
                t * 5 - 2,
            )
            intrinsics = interpolate_intrinsics(
                batch["context"]["intrinsics"][0, 0],
                (
                    batch["context"]["intrinsics"][0, 1]
                    if v == 2
                    else batch["target"]["intrinsics"][0, 0]
                ),
                t * 5 - 2,
            )
            return extrinsics @ tf, intrinsics[None]

        return self.render_video_generic(
            batch,
            trajectory_fn,
            "interpolation_exagerrated",
            num_frames=300,
            smooth=False,
            loop_reverse=False,
        )

    @rank_zero_only
    def render_video_generic(
        self,
        batch: BatchedExample,
        trajectory_fn: TrajectoryFn,
        name: str,
        num_frames: int = 90,
        smooth: bool = True,
        loop_reverse: bool = True,
    ) -> None:
        # Render probabilistic estimate of scene.
        gaussians_prob,_ = self.encoder(batch["context"], self.global_step, False)
        gaussians_det = self.encoder(batch["context"], self.global_step, True)

        t = torch.linspace(0, 1, num_frames, dtype=torch.float32, device=self.device)
        if smooth:
            t = (torch.cos(torch.pi * (t + 1)) + 1) / 2

        extrinsics, intrinsics = trajectory_fn(t)

        _, _, _, h, w = batch["context"]["image"].shape

        # Color-map the result.
        def depth_map(result):
            near = result[result > 0][:16_000_000].quantile(0.01).log()
            far = result.view(-1)[:16_000_000].quantile(0.99).log()
            result = result.log()
            result = 1 - (result - near) / (far - near)
            result = apply_color_map_to_image(result, "turbo")
            return result

        # TODO: Interpolate near and far planes?
        near = repeat(batch["context"]["near"][:, 0], "b -> b v", v=num_frames)
        far = repeat(batch["context"]["far"][:, 0], "b -> b v", v=num_frames)
        output_prob,_ = self.decoder.forward(
            gaussians_prob, extrinsics, intrinsics, near, far, (h, w), "depth"
        )

        #debug
        # images_prob = [
        #     vcat(rgb, depth) for rgb, depth in zip(output_prob.color[0], depth_map(output_prob.depth[0]))
        # ]

        images_prob = []
        for rgb, depth in zip(output_prob.color[0], depth_map(output_prob.depth[0])):
            # 处理 rgb: 可能是 (H, W, 3) → 转为 (3, H, W)
            if rgb.ndim == 3 and rgb.shape[-1] == 3:
                rgb = rgb.permute(2, 0, 1)  # HWC -> CHW
            elif rgb.ndim == 2:
                rgb = rgb[None]  # (H, W) -> (1, H, W)

            # 处理 depth: 通常是 (H, W) → 转为 (1, H, W)
            if depth.ndim == 2:
                depth = depth[None]
            elif depth.ndim == 3 and depth.shape[-1] == 1:
                depth = depth.squeeze(-1)[None]  # (H, W, 1) -> (1, H, W)

            # 现在两者都是 (C, H, W)，可以安全调用 vcat
            images_prob.append(vcat(rgb, depth, align="start"))

        output_det,_ = self.decoder.forward(
            gaussians_det, extrinsics, intrinsics, near, far, (h, w), "depth"
        )
        images_det = [
            vcat(rgb, depth)
            for rgb, depth in zip(output_det.color[0], depth_map(output_det.depth[0]))
        ]

        # print(images_det[0].ndim)

        #debug
        # if images_prob[0].shape[0] == 1:
        #
        #     images = [
        #         add_border(
        #             hcat(
        #                 add_label(image_prob, "Probabilistic"),
        #                 add_label(image_det, "Deterministic"),
        #             )
        #         )
        #         for image_prob, image_det in zip(images_prob, images_det)
        #     ]
        # else:
        images = [
            # add_border(
            #     hcat(
            #         add_label(image_prob, "Probabilistic"),
            #         add_label(image_det, "Deterministic"),
            #     )
            #)

                hcat(
                    image_prob, image_det
                )

            for image_prob, image_det in zip(images_prob, images_det)
        ]
        video = torch.stack(images)
        video = (video.clip(min=0, max=1) * 255).type(torch.uint8).cpu().numpy()
        if loop_reverse:
            video = pack([video, video[::-1][1:-1]], "* c h w")[0]
        visualizations = {
            f"video/{name}": wandb.Video(video[None], fps=30, format="mp4")
        }

        # Since the PyTorch Lightning doesn't support video logging, log to wandb directly.
        # try:
        #     wandb.log(visualizations)
        # except Exception:
        #     assert isinstance(self.logger, LocalLogger)
        #     for key, value in visualizations.items():
        #         tensor = value._prepare_video(value.data)
        #         clip = mpy.ImageSequenceClip(list(tensor), fps=value._fps)
        #         dir = LOG_PATH / key
        #         dir.mkdir(exist_ok=True, parents=True)
        #         clip.write_videofile(
        #             str(dir / f"{self.global_step:0>6}.mp4"), logger=None
        #         )

        # 替换原来的 try-except 块
        try:
            wandb.log(visualizations)
        except Exception:
            assert isinstance(self.logger, LocalLogger)
            for key, value in visualizations.items():
                # 不要依赖 value._fps！直接用你知道的 fps=30
                tensor = value._prepare_video(value.data)  # 这个方法仍然可用
                clip = mpy.ImageSequenceClip(list(tensor), fps=20)  # ← 固定 fps=30
                dir = LOG_PATH / key
                dir.mkdir(exist_ok=True, parents=True)
                clip.write_videofile(
                    str(dir / f"{self.global_step:0>6}.mp4"), logger=None
                )

    def configure_optimizers(self):
        optimizer = optim.Adam(self.parameters(), lr=self.optimizer_cfg.lr)
        warm_up_steps = self.optimizer_cfg.warm_up_steps
        warm_up = torch.optim.lr_scheduler.LinearLR(
            optimizer,
            1 / warm_up_steps,
            1,
            total_iters=warm_up_steps,
        )
        return {
            "optimizer": optimizer,
            "lr_scheduler": {
                "scheduler": warm_up,
                "interval": "step",
                "frequency": 1,
            },
        }


def flow_to_color(flow):
    """
    将光流图转换为伪彩色图
    Args:
        flow: shape (2, H, W) - 光流tensor [u, v]
    Returns:
        color_flow: shape (3, H, W) - 伪彩色光流图
    """
    # 将tensor转换为numpy数组
    flow_np = flow.permute(1, 2, 0).cpu().numpy()  # (H, W, 2)

    # 计算光流的幅值和角度
    magnitude = np.sqrt(flow_np[:, :, 0] ** 2 + flow_np[:, :, 1] ** 2)
    angle = np.arctan2(flow_np[:, :, 1], flow_np[:, :, 0])  # y分量在前，x分量在后

    # 将角度从 [-π, π] 映射到 [0, 180]，幅值归一化
    angle_deg = (angle + np.pi) * 180 / (2 * np.pi)  # [0, 180]

    # 归一化幅值到 [0, 255]
    max_magnitude = np.max(magnitude)
    if max_magnitude > 0:
        magnitude_normalized = (magnitude / max_magnitude) * 255
    else:
        magnitude_normalized = magnitude

    # 创建HSV图像
    hsv = np.zeros((flow_np.shape[0], flow_np.shape[1], 3), dtype=np.uint8)
    hsv[:, :, 0] = angle_deg  # 色调 (H) - 表示方向
    hsv[:, :, 1] = 255  # 饱和度 (S) - 最大饱和度
    hsv[:, :, 2] = magnitude_normalized.astype(np.uint8)  # 亮度 (V) - 表示幅值

    # 转换为BGR，然后转为RGB
    bgr = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
    rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)

    # 转换回tensor，形状为 (3, H, W)
    color_flow = torch.from_numpy(rgb).permute(2, 0, 1).float() / 255.0

    return color_flow


def postprocess_flow_tensor(flow_tensor):
    """
    对光流tensor进行后处理并转换为伪彩色
    Args:
        flow_tensor: shape (3, H, W), 光流信息在前两个通道
    Returns:
        processed_tensor: shape (3, H, W) - 伪彩色光流图
    """
    # 提取前两个通道的光流
    flow_channels = flow_tensor[:2]  # (2, H, W) - u, v 光流

    # 将光流转换为伪彩色图
    color_flow = flow_to_color(flow_channels)  # (3, H, W)

    # 第三个通道（如果有特殊含义）可以保留或替换
    # 如果第三个通道不需要，就返回伪彩色光流
    # 如果需要保留第三个通道的某些信息，可以考虑融合

    return color_flow
def add_zero_channel(tensor):
    """
    将 (2, 1, 2, 240, 320) 的tensor添加一个全零通道变成 (2, 1, 3, 240, 320)
    新通道添加到最后一个通道位置
    """
    batch_size, dim1, channels, height, width = tensor.shape

    # 创建一个形状为 (2, 1, 1, 240, 320) 的全零tensor
    zero_channel = torch.zeros(batch_size, dim1, 1, height, width, dtype=tensor.dtype, device=tensor.device)

    # 将原tensor和零通道在通道维度上连接
    result = torch.cat([tensor, zero_channel], dim=2)

    return result


# def load_partial_pretrained(model, pretrained_path):
#     """
#     部分加载预训练模型并冻结指定层
#
#     Args:
#         model: 当前模型
#         pretrained_path: 预训练模型路径
#         freeze_layers: 需要冻结的层名列表
#     """
#     pretrained_dict = torch.load(pretrained_path)
#     model_dict = model.state_dict()
#
#     # 加载匹配的参数
#     for name, param in pretrained_dict['state_dict'].items():
#         name = name.split(".",maxsplit=1)[-1]
#         if name in model_dict and param.shape == model_dict[name].shape:
#             model_dict[name].copy_(param)
#             print(f"Loaded: {name}")
def load_partial_pretrained(model, pretrained_path, freeze_layers=None):
    """
    部分加载预训练模型并冻结指定层
    如果 freeze_layers 为 None，则冻结所有加载的参数
    """
    pretrained_dict = torch.load(pretrained_path)
    model_dict = model.state_dict()

    # 加载匹配的参数
    loaded_layers = []
    for name, param in pretrained_dict['state_dict'].items():
        clean_name = name.split(".", maxsplit=1)[-1]
        if clean_name in model_dict and param.shape == model_dict[clean_name].shape:
            model_dict[clean_name].copy_(param)
            loaded_layers.append(clean_name)
            print(f"Loaded: {clean_name}")

    # 确定要冻结的层
    if freeze_layers is None:
        # 如果没有指定要冻结的层，默认冻结所有加载的层
        layers_to_freeze = loaded_layers
    else:
        layers_to_freeze = freeze_layers

    # 冻结指定层
    for name, param in model.named_parameters():
        if name in layers_to_freeze:
            param.requires_grad = False
            print(f"Frozen: {name}")

    # 冻结指定层
    # for name, param in model.named_parameters():
    #     if name in freeze_layers:
    #         param.requires_grad = False
    #         print(f"Frozen: {name}")
    #
    # # 可选：打印冻结的层信息
    # frozen_count = sum(1 for name, param in model.named_parameters() if not param.requires_grad)
    # total_params = sum(1 for param in model.parameters())
    # print(f"Frozen {frozen_count}/{total_params} parameters")


