from dataclasses import dataclass
from typing import Literal, Optional
import torch
import torch.autograd.profiler as profiler
from jaxtyping import Float
from torch import Tensor, nn


@dataclass
class MlpCfg:
    n_blocks: int = 8
    d_hidden: int = 256
    combine_layer: int = 0  # 0 means no latent features
    combine_type: Literal["mean"] = "mean"
    beta: float = 0.0  # 0.0 means ReLU, >0 means Softplus


@dataclass
class MLPOutput:
    # output: Float[Tensor, "camera sample d_out"]
    output: Float[Tensor, "..."]  # 任意维度
    features: Float[Tensor, "..."] | None = None
    # features: Float[Tensor, "camera sample d_out"] | None


class ResnetBlockFC(nn.Module):
    """
    Fully connected ResNet Block class.
    :param size_in (int): input dimension
    :param size_out (int): output dimension
    :param size_h (int): hidden dimension
    :param beta (float): softplus beta, 0.0 = ReLU
    """

    def __init__(self, size_in: int, size_out: Optional[int] = None, size_h: Optional[int] = None, beta: float = 0.0):
        super().__init__()
        # Attributes
        if size_out is None:
            size_out = size_in

        if size_h is None:
            size_h = min(size_in, size_out)

        self.size_in = size_in
        self.size_h = size_h
        self.size_out = size_out

        # Submodules
        self.fc_0 = nn.Linear(size_in, size_h)
        self.fc_1 = nn.Linear(size_h, size_out)

        # Initialize weights
        nn.init.constant_(self.fc_0.bias, 0.0)
        nn.init.kaiming_normal_(self.fc_0.weight, a=0, mode="fan_in")
        nn.init.constant_(self.fc_1.bias, 0.0)
        nn.init.zeros_(self.fc_1.weight)

        # Activation function
        if beta > 0:
            self.activation = nn.Softplus(beta=beta)
        else:
            self.activation = nn.ReLU()

        # Shortcut connection
        if size_in == size_out:
            self.shortcut = None
        else:
            self.shortcut = nn.Linear(size_in, size_out, bias=False)
            nn.init.kaiming_normal_(self.shortcut.weight, a=0, mode="fan_in")

    def forward(self, x: Tensor) -> Tensor:
        with profiler.record_function("resblock"):
            net = self.fc_0(self.activation(x))
            dx = self.fc_1(self.activation(net))

            if self.shortcut is not None:
                x_s = self.shortcut(x)
            else:
                x_s = x
            return x_s + dx


class ResnetFC(nn.Module):
    """
    A more user-friendly ResNet-based MLP that can be easily instantiated.

    Usage examples:
    # Simple case: input -> hidden -> output
    mlp = ResnetFC(d_in=64, d_out=32, n_blocks=4, d_hidden=128)

    # With latent features (like in NeRF)
    mlp = ResnetFC(d_in=64, d_out=32, d_latent=64, n_blocks=8, combine_layer=4)

    # With default settings
    mlp = ResnetFC(d_in=128, d_out=10)
    """

    def __init__(
            self,
            d_in: int,
            d_out: int,
            d_latent: int = 0,
            n_blocks: int = 8,
            d_hidden: int = 256,
            combine_layer: int = 0,
            beta: float = 0.0,
            activation: str = "relu",  # "relu" or "softplus"
    ):
        """
        :param d_in: input dimension
        :param d_out: output dimension
        :param d_latent: latent feature dimension (0 = disable latent features)
        :param n_blocks: number of residual blocks
        :param d_hidden: hidden dimension throughout network
        :param combine_layer: number of blocks to combine with latent features
        :param beta: softplus beta (0.0 = ReLU, >0 = Softplus)
        :param activation: activation function type ("relu" or "softplus")
        """
        super().__init__()

        # Store config for reference
        self.cfg = MlpCfg(
            n_blocks=n_blocks,
            d_hidden=d_hidden,
            combine_layer=combine_layer,
            combine_type="mean",
            beta=beta if activation == "softplus" else 0.0
        )

        self.d_latent = d_latent

        # Input layer
        if d_in > 0:
            self.lin_in = nn.Linear(d_in, d_hidden)
            nn.init.constant_(self.lin_in.bias, 0.0)
            nn.init.kaiming_normal_(self.lin_in.weight, a=0, mode="fan_in")

        # Output layer
        self.lin_out = nn.Linear(d_hidden, d_out)
        nn.init.constant_(self.lin_out.bias, 0.0)
        nn.init.kaiming_normal_(self.lin_out.weight, a=0, mode="fan_in")

        # Residual blocks
        self.blocks = nn.ModuleList([
            ResnetBlockFC(d_hidden, beta=self.cfg.beta)
            for _ in range(n_blocks)
        ])

        # Latent feature layers (if enabled)
        if d_latent > 0:
            n_lin_z = min(combine_layer, n_blocks)
            self.lin_z = nn.ModuleList([
                nn.Linear(d_latent, d_hidden)
                for _ in range(n_lin_z)
            ])
            for layer in self.lin_z:
                nn.init.constant_(layer.bias, 0.0)
                nn.init.kaiming_normal_(layer.weight, a=0, mode="fan_in")

        # Activation function
        if activation == "softplus":
            self.activation = nn.Softplus(beta=max(beta, 0.01))  # Avoid beta=0
        else:
            self.activation = nn.ReLU()

    def forward(
            self,
            x: Float[Tensor, "*batch d_in"],
            z: Optional[Float[Tensor, "*batch d_latent"]] = None,  # features (optional)
             # input
            compute_features: bool = False,
    ) :
        x = self.lin_in(x)

        features = [] if compute_features else None

        for block_id in range(self.cfg.n_blocks):
            # Add latent features if enabled and within combine_layer
            if self.d_latent > 0 and z is not None and block_id < self.cfg.combine_layer:
                tz = self.lin_z[block_id](z)
                x = x + tz

            x = self.blocks[block_id](x)

            if compute_features:
                features.append(x)

        output = self.lin_out(self.activation(x))

        if compute_features and features:
            features = torch.cat(features, dim=-1)
        elif not compute_features:
            features = None

        return MLPOutput(output=output, features=features)


# 简单的工厂函数，更方便使用
def create_resnet_mlp(
        d_in: int,
        d_out: int,
        d_latent: int = 0,
        n_blocks: int = 8,
        d_hidden: int = 256,
        combine_layer: int = 0,
        activation: str = "relu",
        beta: float = 0.0,
) -> ResnetFC:
    """
    Factory function to create ResnetFC with sensible defaults.
    """
    return ResnetFC(
        d_in=d_in,
        d_out=d_out,
        d_latent=d_latent,
        n_blocks=n_blocks,
        d_hidden=d_hidden,
        combine_layer=combine_layer,
        activation=activation,
        beta=beta,
    )


class JacobianHead(nn.Module):
    def __init__(
            self,
            input_dim: int = 128,
            output_groups: int = 4,
            output_features: int = 3,
            n_blocks: int = 8,
            d_hidden: int = 256,
            activation: str = "normal",
            init_method: str = "zero",  # 'zero', 'normal', 'xavier', 'kaiming'
    ):
        super().__init__()
        self.output_shape = (output_groups, output_features)
        self.total_output_dim = output_groups * output_features
        self.init_method = "zero"

        self.mlp = ResnetFC(
            d_in=input_dim,
            d_out=self.total_output_dim,
            n_blocks=n_blocks,
            d_hidden=d_hidden,
            activation=activation,
        )

        self._initialize_weights()

    def _initialize_weights(self):
        """根据指定方法初始化权重"""
        for name, param in self.named_parameters():
            if 'weight' in name:
                if self.init_method == 'zero':
                    nn.init.zeros_(param)
                elif self.init_method == 'normal':
                    nn.init.normal_(param, mean=0.0, std=0.01)
                elif self.init_method == 'xavier':
                    nn.init.xavier_uniform_(param)
                elif self.init_method == 'kaiming':
                    nn.init.kaiming_uniform_(param, nonlinearity='relu')
            elif 'bias' in name:
                if self.init_method == 'zero':
                    nn.init.zeros_(param)
                else:
                    nn.init.zeros_(param)  # 通常偏置初始化为0

    def forward(self, x):
        original_shape = x.shape
        B, V, HW = original_shape[:3]

        x_reshaped = x.view(-1, x.shape[-1])
        output = self.mlp(x=x_reshaped)

        output_features = output.output.view(
            B, V, HW, self.output_shape[0], self.output_shape[1]
        )

        return output_features



if __name__ == "__main__":
    # 方法1: 直接使用
    transformer1 = JacobianHead(input_dim=128, output_groups=4, output_features=3)
    x = torch.randn(2, 1, 76800, 128)
    result1 = transformer1(x)
    print(f"Method 1 - Input: {x.shape}, Output: {result1.shape}")

    # 方法2: 使用更灵活的版本
    transformer2 = JacobianHead(
        input_dim=128,
        output_groups=4,
        output_features=3,
        n_blocks=6,
        d_hidden=512
    )
    result2 = transformer2(x)
    print(f"Method 2 - Input: {x.shape}, Output: {result2.shape}")

    # 你也可以用于其他形状
    x2 = torch.randn(1, 2, 10000, 128)  # 不同的batch和HW
    result3 = transformer2(x2)
    print(f"Method 2 with different shape - Input: {x2.shape}, Output: {result3.shape}")